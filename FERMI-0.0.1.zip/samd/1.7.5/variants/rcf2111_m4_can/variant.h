/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _VARIANT_FEATHER_M4_
#define _VARIANT_FEATHER_M4_

// The definitions here needs a SAMD core >=1.6.10
#define ARDUINO_SAMD_VARIANT_COMPLIANCE 10610

/*----------------------------------------------------------------------------
 *        Definitions
 *----------------------------------------------------------------------------*/

/** Frequency of the board main oscillator */
#define VARIANT_MAINOSC		(32768ul)

/** Master clock frequency */
#define VARIANT_MCK        (F_CPU)

#define VARIANT_GCLK0_FREQ (F_CPU)
#define VARIANT_GCLK1_FREQ (48000000UL)
#define VARIANT_GCLK2_FREQ (100000000UL)

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/

#include "WVariant.h"

#ifdef __cplusplus
#include "SERCOM.h"
#include "Uart.h"
#endif // __cplusplus

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

/*----------------------------------------------------------------------------
 *        Pins
 *----------------------------------------------------------------------------*/

// Number of pins defined in PinDescription array
#define PINS_COUNT           (44u)
#define NUM_DIGITAL_PINS     (23u)
#define NUM_ANALOG_INPUTS    (2u)
#define NUM_ANALOG_OUTPUTS   (1u)
#define analogInputToDigitalPin(p)  ((p < 6u) ? (p) + 14u : -1)

#define digitalPinToPort(P)        ( &(PORT->Group[g_APinDescription[P].ulPort]) )
#define digitalPinToBitMask(P)     ( 1 << g_APinDescription[P].ulPin )
//#define analogInPinToBit(P)        ( )
#define portOutputRegister(port)   ( &(port->OUT.reg) )
#define portInputRegister(port)    ( &(port->IN.reg) )
#define portModeRegister(port)     ( &(port->DIR.reg) )
#define digitalPinHasPWM(P)        ( g_APinDescription[P].ulPWMChannel != NOT_ON_PWM || g_APinDescription[P].ulTCChannel != NOT_ON_TIMER )

/*
 * digitalPinToTimer(..) is AVR-specific and is not defined for SAMD
 * architecture. If you need to check if a pin supports PWM you must
 * use digitalPinHasPWM(..).
 *
 * https://github.com/arduino/Arduino/issues/1833
 */
// #define digitalPinToTimer(P)

// LEDs
#define PIN_LED_0             (2u)
#define PIN_LED               PIN_LED_0
#define LED_BUILTIN           PIN_LED_0
#define LED0                  PIN_LED_0

// BUTTOMs
#define PIN_BTN_0             (3u)
#define PIN_BUTTON            PIN_BTN_0
#define BUTTOM_BUILTIN        PIN_BTN_0

/*
 * Serial interfaces
 */

// Serial1 (SERCOM2)
#define PIN_SERIAL1_RX        (0ul)
#define PIN_SERIAL1_TX        (1ul)
#define PAD_SERIAL1_RX        (SERCOM_RX_PAD_1)
#define PAD_SERIAL1_TX        (UART_TX_PAD_0)

// Serial2 (SERCOM5)
#define PIN_SERIAL2_RX        (35ul)
#define PIN_SERIAL2_TX        (36ul)
#define PAD_SERIAL2_RX        (SERCOM_RX_PAD_1)
#define PAD_SERIAL2_TX        (UART_TX_PAD_0)

// Serial3 (SERCOM0)
#define PIN_SERIAL3_RX        (42ul)
#define PIN_SERIAL3_TX        (43ul)
#define PAD_SERIAL3_RX        (SERCOM_RX_PAD_1)
#define PAD_SERIAL3_TX        (UART_TX_PAD_0)

/*
 * CAN
 */
#define PIN_CAN_TX            (4)
#define PIN_CAN_RX            (5)
#define PIN_CAN_STANDBY       (6)

/*
 * Wire Interfaces
 */
#define WIRE_INTERFACES_COUNT 1

#define PIN_WIRE_SDA          (7u)
#define PIN_WIRE_SCL          (8u)
#define PERIPH_WIRE           sercom7
#define WIRE_IT_HANDLER       SERCOM7_Handler
#define WIRE_IT_HANDLER_0     SERCOM7_0_Handler
#define WIRE_IT_HANDLER_1     SERCOM7_1_Handler
#define WIRE_IT_HANDLER_2     SERCOM7_2_Handler
#define WIRE_IT_HANDLER_3     SERCOM7_3_Handler

static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

/*
 *  On-board QSPI Flash
 */
#define EXTERNAL_FLASH_DEVICES      SST26F064B // GD25Q16C
#define EXTERNAL_FLASH_USE_QSPI

//QSPI Pins
#define PIN_QSPI_SCK    ( 9u)
#define PIN_QSPI_CS     (10u)
#define PIN_QSPI_IO0    (11u)
#define PIN_QSPI_IO1    (12u)
#define PIN_QSPI_IO2    (13u)
#define PIN_QSPI_IO3    (14u)

/*
 * USB
 */

#define PIN_USB_HOST_ENABLE (NOT_A_PORT)
#define PIN_USB_DM          (29ul)
#define PIN_USB_DP          (30ul)

/*
 * SDHC
 */

#define MCDA0     (17u)
#define MCDA1     (18u)
#define MCDA2     (19u)
#define MCDA3     (20u)
#define MCCK      (21u)
#define MCCDA     (22u)
#define DETECT    (23u)
#define PROTECT   (24u)


/*
 * SPI Interfaces
 */
#define SPI_INTERFACES_COUNT 1

#define PIN_SPI_MISO         (39u)
#define PIN_SPI_MOSI         (38u)
#define PIN_SPI_SCK          (40u)
#define PERIPH_SPI           sercom6
#define PAD_SPI_TX           SPI_PAD_0_SCK_1
#define PAD_SPI_RX           SERCOM_RX_PAD_3

static const uint8_t SS	  = 37 ;	
static const uint8_t MOSI = PIN_SPI_MOSI ;
static const uint8_t MISO = PIN_SPI_MISO ;
static const uint8_t SCK  = PIN_SPI_SCK ;

/*
 * EXT2-PIN
 */
#define EXT2_PIN3   (25u)
#define EXT2_PIN4   (26u)
#define EXT2_PIN5   (27u)
#define EXT2_PIN6   (28u)
#define EXT2_PIN7   (29u)
#define EXT2_PIN8   (30u)
#define EXT2_PIN9   (31u)
#define EXT2_PIN10  (32u)
#define EXT2_PIN11  (33u)
#define EXT2_PIN12  (34u)
#define EXT2_PIN13  (35u)
#define EXT2_PIN14  (36u)
#define EXT2_PIN15  (37u)
#define EXT2_PIN16  (38u)
#define EXT2_PIN17  (39u)
#define EXT2_PIN18  (40u)

/*
 * Analog pins
 */
#define PIN_A0               (25ul)
#define PIN_A1               (26ul)

#define PIN_DAC0             (41ul)
#define PIN_DAC1             (41ul)

static const uint8_t A0  = PIN_A0;
static const uint8_t A1  = PIN_A1;
static const uint8_t A2  = -1;
static const uint8_t A3  = -1;
static const uint8_t A4  = -1;
static const uint8_t A5  = -1;
static const uint8_t A6  = -1;

static const uint8_t DAC0 = PIN_DAC0;

#define ADC_RESOLUTION		12

/*
 * I2S Interfaces
 */
#define I2S_INTERFACES_COUNT 1

#define I2S_DEVICE          0
#define I2S_CLOCK_GENERATOR 3

#define PIN_I2S_SDO          (11u)
#define PIN_I2S_SDI          (12u)
#define PIN_I2S_SCK          PIN_SERIAL1_TX
#define PIN_I2S_FS           (10u)
#define PIN_I2S_MCK          PIN_SERIAL1_RX

#if !defined(VARIANT_QSPI_BAUD_DEFAULT)
  // TODO: meaningful value for this
  #define VARIANT_QSPI_BAUD_DEFAULT 5000000
#endif

#ifdef __cplusplus
}
#endif

/*----------------------------------------------------------------------------
 *        Arduino objects - C++ only
 *----------------------------------------------------------------------------*/

#ifdef __cplusplus

/*	=========================
 *	===== SERCOM DEFINITION
 *	=========================
*/
extern SERCOM sercom0;
extern SERCOM sercom1;
extern SERCOM sercom2;
extern SERCOM sercom3;
extern SERCOM sercom4;
extern SERCOM sercom5;
extern SERCOM sercom6;
extern SERCOM sercom7;

extern Uart Serial1;
extern Uart Serial2;
extern Uart Serial3;

#endif

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_USBVIRTUAL      Serial
#define SERIAL_PORT_MONITOR         Serial
// Serial has no physical pins broken out, so it's not listed as HARDWARE port
#define SERIAL_PORT_HARDWARE        Serial1
#define SERIAL_PORT_HARDWARE_OPEN   Serial1

#endif /* _VARIANT_FEATHER_M4_ */

