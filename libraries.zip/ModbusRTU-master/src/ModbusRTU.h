/* ModBus RTU */
#include <arduino.h>


#ifndef RS485default_RTS_pin
#define RS485default_RTS_pin	-1
#endif

#define MULTT 1

#define MAX_DATA	32
#define MAXBUF 		((7)+MAX_DATA*2+2+1)

enum DATA_TYPE { NO_TYPE=0, BOOL, INTEGER };

/* definiciones de polling records */
/* definiciones de comandos (funciones) implementados del protocolo */
#define READ_COIL_STATUS        			01 // No implementado en Mbm12
#define READ_INPUT_STATUS       			02 // No implementado en Mbm12
#define READ_HOLDING_REGISTERS				03
#define READ_INPUT_REGISTERS				04
#define FORCE_SINGLE_COIL       			05 // No implementado en Mbm12
#define WRITE_HOLDING_REGISTER  			06
#define READ_EXCEPTION_STATUS				07 // No implementado en Mbm12 ni en Mbs12
#define FORCE_MULTIPLE_COIL     			15 // 0x0F
#define WRITE_MULTIPLE_HOLDING_REGISTERS  	16 // 0x10
#define WRITE_MASK_4X_REGISTER				22 // 0x16 No implementado en Mbs12
#define USER_100							100
#define USER_101							101

/* definiciones de campo de errores respuesta con error segun Modicom originales PI-MBUS-300 Rev. H abril 1996 */

#define	ILLEGAL_FUNCTION					1
#define	ILLEGAL_DATA_ADDRESS				2
#define	ILLEGAL_DATA_VALUE					3
#define	DEVICE_FAILURE						4
#define	ACKNOWLEDGE							5
#define	BUSY_REJECT_MSG						6
#define NEGATIVE_ACKNOWLEDGE				7
#define MEMORY_PARITY_ERROR					8
// inclusion L.F no standard Modbus 
#define CHK_ERR 							9
#define WRITE_PROTECT 						10

enum COMM_STATES_MBM { MBM_COMM_CLOSE=0 ,LIBRE, ARMAR_PEDIDO, TX_PEDIDO,ESPERA_TX, POST_TX, ESPERA_RX_DATA, REINTENTO_POLL, ESPERA_RPT, FIN_POLL, FIN_POLL_TOUT , ULTIMO_POLL, POLL_ERROR };

// Parser errors
#define MBM_COMMAND_OK				0
#define MBM_TIME_OUT  				-1
#define MBM_BAD_STATION 			-2
#define MBM_BAD_DATA 				-3
#define MBM_BAD_LRC 				-4
#define MBM_BAD_CRC 				-4
#define MBM_ABORT					-5
#define MBM_BAD_DATA_ADDR 			-6
#define MBM_BAD_RTU_ADDR 			-7
#define MBM_BAD_RET_FUNC 			-8
#define MBM_BAD_DATA_NUM 			-9
#define MBM_BAD_RET_BCOUNT 			-10

// returned modbus errors
#define	MBM_ILLEGAL_FUNCTION		-11
#define	MBM_ILLEGAL_DATA_ADDRESS	-12
#define	MBM_ILLEGAL_DATA_VALUE		-13
#define	MBM_DEVICE_FAILURE			-14
#define	MBM_ACKNOWLEDGE				-15
#define	MBM_BUSY_REJECT_MSG			-16
#define MBM_NEGATIVE_ACKNOWLEDGE	-17
#define MBM_MEMORY_PARITY_ERROR		-18


// operation error
#define MBM_BAD_POOL_LEN  			-20
#define MBM_BAD_WRITE_RPLY 			-21
#define MBM_BUFFER_OVERFLOW 		-22
#define MBM_BAD_TYPE 				-23
#define MBM_ERROR24  				-24
#define MBM_ERROR25  				-25
#define MBM_ERROR26  				-26
#define MBM_ERROR27  				-27
#define MBM_ERROR28  				-28
#define MBM_DRIVER_ERROR  			-29

// comm errors
#define MBM_COMM_IO_ERR 			-30
#define MBM_COMM_OPEN_ERR 			-31
#define MBM_COMM_CLOSE_ERR 			-32
#define MBM_COMM_RTS_CTS_ERR 		-33
#define MBM_COMM_RTS_DSR_ERR 		-34
#define MBM_COMM_DTR_DCD_ERR 		-35
#define MBM_COMM_DTR_DSR_ERR 		-36
#define MBM_COMM_TX_ERR				-37
#define MBM_COMM_RX_ERR				-38
// global errors
#define MBM_NO_POLLED				-40

#define MBM_DESCONOCIDO 			-99

// definicion de la estructura de un polling record info.
struct _poll_record {
	unsigned char	station; 	/* numero de rtu o data block en plc 0-255 */
	unsigned short	function;	/* funcion a ejecutar en Poll, READ_NUMERIC o WRITE 1 o MULTIPLE */
	unsigned short	address;	/* posicion en rtu o dw en PLC 0-0xffff */
	unsigned char	length;		/* largo del block de datos en unidades (bool, int, etc) */
	unsigned char	type;		/* tipo de datos  ( BOOL, INTEGER, ETC) */
	unsigned char 	*data;		/* hacer casting de este pointer para otros tipos */
	unsigned char	N_data;		/* Largo maximo de datos del Polling Record */
	union {
		struct {
			unsigned short ready :1;        /* Se realizo el polling del record, (lo baja el SAC)*/
			unsigned short polling :1;      /* Se esta realizando el polling del record (lo sube y braja el driver)*/
			unsigned short bit_2 :1;        /* 0x0004 */
			unsigned short bit_3 :1;        /* 0x0008 */
			unsigned short bit_4 :1;        /* 0x0010 */
			unsigned short bit_5 :1;        /* 0x0020 */
			unsigned short bit_6 :1;        /* 0x0040 */
			unsigned short bit_7 :1;        /* 0x0080 */
			unsigned short bit_8 :1;        /* 0x0100 */
			unsigned short repeat_now :1;   /* Realizar el reintento instantaneamente. ( no usuado por ahora) */
			unsigned short do_one :1;       /* Hacer solo un Polling (ej, para WRITE_INPUT ) */
			unsigned short error_poll :1;   /* Si existe algun error, (lo baja el SAC)*/
			unsigned short new_data :1;     /* datos nuevos , lo sube el driver, lo baja el SAC */
			unsigned short over_run :1;     /* Si se realizo un nuevo polling sin una lectura. */
			unsigned short on_poll :1;      /* Activacion (1:Activo 0:Inactivo). */
			unsigned short tag :1;          /* Enable del Polling Record (1:Valido 0:Invalido). */
		}bit;
		unsigned short Wfull;
	} pflag; 							    /* TAG, ON_POLL, OV_RUN, NEW_DATA, ERROR, DO_ONE, READY */

	unsigned short ptimer_reload;		    /* preset de tiempo de polling en ms */
	short pr_error;                         /* error de com en este poll record */
	char repeat_reload;	   	                /* Cantidad de Reintentos */
	struct {
		char repeat;
		unsigned short ptimer;              /* timer de polling en  ms debe ser Int lo que da 640.00 seg o sea un maximo de 10 minutos aprox */
	} parser;							
	
	struct {
		unsigned short total_msg; 			// contador de mensajes totales
		unsigned short total_errors; 		// contador de errores totales (de 0xFFFF pasa a 0 )
		unsigned short time_out_errors; 	// contador de errores totales (de 0xFFFF pasa a 0 )
		unsigned short crc_errors; 	 		// contador de errores totales (de 0xFFFF pasa a 0 )
	} counters;
};

class ModbusMaster {
    private:
        Uart *Comm;
        unsigned long baudrate = 38400;
        int RTS_pin = RS485default_RTS_pin;
        short RTS_mode = 1; // 0: pin low for TX , 1: pin high for TX
        short polling_large = 0;

		void flush_rx( void );
        short verificar_respuesta_write( void );
        short tomar_datos_read( void );
        unsigned short calcular_crc16(unsigned char buff[],short largo);
        short check_crc16(unsigned char *buff, short largo);
        void clear_rts_state( void ) ;
        void set_rts_state( void ) ;

        struct _timer {
            unsigned short rts_time_on; // tiempo entre RTS on y txdata 2.55 seg max
            unsigned short rts_time_off; // tiempo entre txdata y RTS off 2.55 seg max
            unsigned short eom;
            unsigned short rx_time_out;
            unsigned short tx_time_out;
            unsigned short rpt; /* tiempo entre reintentos  */
        } timers ;

	    struct _parser {
    		char poll_flag; 	/* TRUE si en ciclo de polling */
	    	char n_retry; 		/* numero de reintentos por error de cualquier tipo */
		    unsigned int estado_comm = MBM_COMM_CLOSE;
    		short err_comm;

	    	unsigned short nr;			// numero de record de polling ciclado por el parser_mbm
		    unsigned short save_nr; 	// numero de record de polling ciclado por el parser_mbm
							// en curso, salvado al usar el polling record 0 prioritario

    		unsigned char   tx_data[MAXBUF+1];     /* largo=bytes de respuesta+1 */
	    	unsigned char 	rx_data[MAXBUF+1];
		    unsigned short 	ixp;  		/* indices de buffer de poll y de respuesta */
		    unsigned short 	largo_tx; 	/* set por analizar_respuesta, largo de tx_data */
		
		    struct _utime{
			    unsigned short eom; 	// 2.55 seg max
			    unsigned short timer; 	
			    unsigned short time_out;
			    unsigned short pre;
			    unsigned short retry;
		    } utime;
	    } parser;

    public:
        short poll_activo; // Llave de Activacion del Master MODBUS 12
        struct _poll_record *polling_record = NULL;
        ModbusMaster( Uart* Puerto ,  int poll_list_large ):polling_record( new struct _poll_record[poll_list_large])
        {
			Comm = Puerto;
            polling_large = poll_list_large;
        }
        ~ModbusMaster()
        {
            delete [] polling_record;
            polling_large = 0;
        }

        int begin( void );
        int begin( unsigned long baud );
        int begin( unsigned long baud , int rts_pin );

        int end( void );

        short service( void );

        short pollingtime( void );
};

#include "parserF7x7/sacF707C.h"