#include "../ModbusRTU.h"

// Modificado 01/04/2005 by. F.A. - CheckSegTemp modificado para operar siempre y modo relativo o absoluto
// Modificado 13/09/2006 by. F.A. - Agrega posibilidad de modificacion del Modo de trabajo (ej, CIC, PID)
// Modificado 20/10/2021 by. F.A. - Conversion para Arduino FERMI

enum SACF707C_STTS { ERROR =-1, INIT_POLL, POLL, END_POLL, ACTUALIZA, INIT_WRITE , WRITE, END_WRITE };

short init_F707C( F707C *link ) {
	short i;
	for( i = 0 ; i < 8 ; i++ ) {
		link->modulo.modCTRL[i].Wfull = 0;
	}
	link->modulo.enable = true;
	if( link->sac.polling != 0 ) {
		link->sac.estado = INIT_POLL;
		link->sac.Error = FALSE;
		return( TRUE );
	} else {
		link->sac.estado = ERROR;
		link->sac.Error = SAC707C_NO_INITIALIZE;
		return( FALSE );
	}
}

short sac_F707C( F707C *link ) {
	short i;
	switch( link->sac.estado ) {
		case ERROR:
			link->modulo.estado = false;
			if( link->sac.polling->pflag.bit.polling == 0 ) {  
				link->sac.polling->pflag.bit.error_poll = 0;
				link->sac.polling->pflag.bit.on_poll = 0;  
				link->sac.polling->pflag.bit.tag = 0;
			}
			if(( link->sac.Error == FALSE )||( link->modulo.enable != true )) {
				link->sac.Error = FALSE;
				link->sac.estado = INIT_POLL;
			}
			break;
		case INIT_POLL:
			if( link->sac.polling->pflag.bit.polling == 0 ) {  
				if( link->modulo.enable == true ) {
					link->sac.polling->pflag.bit.error_poll = 0;
					link->sac.polling->pflag.bit.on_poll = 0;  
					link->sac.polling->pflag.bit.tag = 0;
					link->sac.polling->station = link->IDF707C;
					link->sac.polling->function = READ_HOLDING_REGISTERS;
					link->sac.polling->address = 8;
					link->sac.polling->length = 32;
					link->sac.polling->N_data = 32; 
					link->sac.polling->type = INTEGER;
					link->sac.polling->data = (unsigned char*)&link->Temperatura;
					link->sac.polling->pflag.bit.do_one = 0;  
					link->sac.polling->pflag.bit.tag = 1;
					link->sac.polling->ptimer_reload = 100; // Tiempo Fijo de Polling 1Seg.
					link->sac.polling->pr_error = FALSE;
					link->sac.polling->pflag.bit.ready = 0;
					link->sac.polling->pflag.bit.on_poll = 1;
					link->sac.estado = POLL;  
				} else {
					link->modulo.estado = true;
					for( i = 0 ; i < 8 ; i++ ) {
						link->Temperatura[i] = 0;
					}
				}
			}
			break;
		case POLL:
			if( link->sac.polling->pflag.bit.error_poll ) {
				link->sac.estado = ERROR;
				link->sac.Error = link->sac.polling->pr_error;	
			} else if ( link->sac.polling->pflag.bit.ready ) {
				link->sac.polling->pflag.bit.new_data = 0;
				link->sac.polling->pflag.bit.ready = 0;
				link->modulo.estado = true;
				link->sac.estado = INIT_POLL;  

				for( i = 0 ; i < 7 ; i++ ) {

					if( link->read_control != 0 ) {
						link->modulo.cfg[i].bit.CTRLON = link->read_control[i] & 0x01;
					}
	
					if( link->read_modo != 0 ) {
						link->modulo.cfg[i].bit.MODO = link->read_modo[i] & 0x03;
					}

					if( link->stts[i].bit.MODO == CICL_MODE ) {
						// Solo si es modo Ciclador
  
  /* Si se encuentra en modo ciclador se fija el setpoint automaticamente en cero, pero no se 
     toca el programado, esto es para que al pasar al modo PID tenga un valor de setpoint aprox.
     y no quede deshabilitadad la zona. */
  						link->modulo.Set_point[i] = 0;

						if( link->read_sintonia != 0 ) {
							link->modulo.sintonia[i] = link->read_sintonia[i];
						}

						if( link->write_stts != 0 ) {
							if( link->stts[i].bit.CTRLON == 1 ) {
								link->write_stts[i] = 1;
							} else {
								link->write_stts[i] = 0;
							}
						}

 						if( link->Sintonia[i] != link->modulo.sintonia[i] ) {
							link->modulo.modCTRL[i].mod.SETPOINT = 1;
							link->modulo.modCTRL[i].mod.SINTONIA = 1;
							link->sac.estado = ACTUALIZA;
						}

					} else {
						// Solo si es modo PID
						if( link->read_setpoint != 0 ) {
							link->modulo.Set_point[i] = link->read_setpoint[i];
						}
						if( link->Set_point[i] != link->modulo.Set_point[i] ) {
							link->modulo.modCTRL[i].mod.SETPOINT = 1;
							link->sac.estado = ACTUALIZA;
						}

						if( link->write_stts != 0 ) {
							if( link->stts[i].bit.CTRLON == 1 ) {
								if( link->stts[i].bit.MED_OK == 0 ) {
									link->modulo.estado = false;
									link->write_stts[i] = 5;// Un problema grabe
									if( link->stts[i].bit.OV_MED_L == 1 ) {
										link->write_stts[i] = 2;
									} 
									if( link->stts[i].bit.OV_MED_H == 1 ) {
										link->write_stts[i] = 3;
									}
								} else {
									link->write_stts[i] = 1;
								}
							} else {
								link->write_stts[i] = 0;
							}
						}
						// Ojo que aca no lee la sintonia sino que la escribe para mantener actualizado el valor.
						if( link->read_sintonia != 0 ) {
							link->read_sintonia[i] = link->Sintonia[i];
						}
					}

					if( link->stts[i].bit.MODO != link->modulo.cfg[i].bit.MODO ) {
						if( link->modulo.cfg[i].bit.MODO != CICL_MODE ) {
							link->modulo.cfg[i].bit.MODO = PID_MODE;
						}
						link->modulo.modCTRL[i].mod.MODE_CTRL = 1;
						link->sac.estado = ACTUALIZA;
					}
					if( link->stts[i].bit.CTRLON != link->modulo.cfg[i].bit.CTRLON ) {
						link->modulo.modCTRL[i].mod.CTRLON = 1;
						link->sac.estado = ACTUALIZA;
					}

					if( link->write_temp != 0 ) {
						link->write_temp[i] = link->Temperatura[i];
					}
				} 
			}
			break;
		case ACTUALIZA:
			if( link->sac.polling->pflag.bit.polling == 0 ) {  
				link->sac.polling->pflag.bit.on_poll = 0;  
				link->sac.polling->pflag.bit.tag = 0;
				for( i = 0 ; i < 8 ; i++ ) {
					//Filtra el comando de escritura
					link->modulo.modCTRL[i].Wfull &= 0x7407;
					link->modulo.cfg[i].bit.SINTON = 1;
				}
				link->sac.polling->pflag.bit.on_poll = 0;  
				link->sac.polling->pflag.bit.tag = 0;
				link->sac.polling->station = link->IDF707C;
				link->sac.polling->function = WRITE_MULTIPLE_HOLDING_REGISTERS;
				link->sac.polling->address = 144;
				link->sac.polling->length = 16;
				link->sac.polling->N_data = 16; 
				link->sac.polling->type = INTEGER;
				link->sac.polling->data = (unsigned char*)link->modulo.Set_point;
				link->sac.polling->pflag.bit.do_one = 1;  
				link->sac.polling->pflag.bit.tag = 1;
				link->sac.polling->ptimer_reload = 0; 
				link->sac.polling->pr_error = FALSE;
				link->sac.polling->pflag.bit.ready = 0;
				link->sac.polling->pflag.bit.on_poll = 1;
				link->sac.estado = INIT_WRITE;
			}
			break;
		case INIT_WRITE:
			if( link->sac.polling->pflag.bit.error_poll ) {
				link->sac.estado = ERROR;
				link->sac.Error = link->sac.polling->pr_error;	
			} else if ( link->sac.polling->pflag.bit.ready ) {
				if( link->sac.polling->pflag.bit.polling == 0 ) {  
					link->sac.polling->pflag.bit.on_poll = 0;  
					link->sac.polling->pflag.bit.tag = 0;
					link->sac.polling->pflag.bit.on_poll = 0;  
					link->sac.polling->pflag.bit.tag = 0;
					link->sac.polling->station = link->IDF707C;
					link->sac.polling->function = WRITE_MULTIPLE_HOLDING_REGISTERS;
					link->sac.polling->address = 216;
					link->sac.polling->length = 8;
					link->sac.polling->N_data = 8; 
					link->sac.polling->type = INTEGER;
					link->sac.polling->data = (unsigned char*)link->modulo.sintonia;
					link->sac.polling->pflag.bit.do_one = 1;  
					link->sac.polling->pflag.bit.tag = 1;
					link->sac.polling->ptimer_reload = 0; 
					link->sac.polling->pr_error = FALSE;
					link->sac.polling->pflag.bit.ready = 0;
					link->sac.polling->pflag.bit.on_poll = 1;
					link->modulo.estado = true;
					link->sac.estado = WRITE;
				}
			} 
			break;
		case WRITE:
			if( link->sac.polling->pflag.bit.error_poll ) {
				link->sac.estado = ERROR;
				link->sac.Error = link->sac.polling->pr_error;	
			} else if ( link->sac.polling->pflag.bit.ready ) {
				if( link->sac.polling->pflag.bit.polling == 0 ) {  
					link->sac.polling->pflag.bit.on_poll = 0;  
					link->sac.polling->pflag.bit.tag = 0;
					link->sac.polling->pflag.bit.on_poll = 0;  
					link->sac.polling->pflag.bit.tag = 0;
					link->sac.polling->station = link->IDF707C;
					link->sac.polling->function = WRITE_MULTIPLE_HOLDING_REGISTERS;
					link->sac.polling->address = 136;
					link->sac.polling->length = 8;
					link->sac.polling->N_data = 8; 
					link->sac.polling->type = INTEGER;
					link->sac.polling->data = (unsigned char*)link->modulo.modCTRL;
					link->sac.polling->pflag.bit.do_one = 1;  
					link->sac.polling->pflag.bit.tag = 1;
					link->sac.polling->ptimer_reload = 0; 
					link->sac.polling->pr_error = FALSE;
					link->sac.polling->pflag.bit.ready = 0;
					link->sac.polling->pflag.bit.on_poll = 1;
					link->sac.estado = END_WRITE;
				}
			}
			break;
		case END_WRITE:
			if( link->sac.polling->pflag.bit.error_poll ) {
				link->sac.estado = ERROR;
				link->sac.Error = link->sac.polling->pr_error;	
			} else if ( link->sac.polling->pflag.bit.ready ) {
				link->sac.polling->pflag.bit.new_data = 0;
				link->modulo.estado = true;
				for( i = 0 ; i < 7 ; i++ ) {
					link->modulo.modCTRL[i].Wfull = 0;
				}
				link->sac.estado = INIT_POLL;
			} 
			break;
	}
	return( link->sac.estado );
}


/* Establece el SetPoint de una zona del modulo apuntado
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : zona sera el numero de zona dentro del modulo 
         : SetPoint el valor elegido de temperatura a regular
*/
short SetPointF707C( F707C *link , char zona , short SetPoint ) {
	if( zona > 7 ) { return( FALSE ); }
	link->modulo.Set_point[zona] = SetPoint;
	if( link->read_setpoint != 0 ) {
		link->read_setpoint[zona] = SetPoint;
	}
	if( link->modulo.estado == true ) {
		return( TRUE );
	} else {
		return( FALSE );
	}
}

//-------------------------------------------------------------------------------

/* Establece el Ciclo de Trabajo de una zona del modulo apuntado
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : zona sera el numero de zona dentro del modulo 
         : Sintonia el valor elegido ciclo de trabajo (DutyCicle)
*/
short SintoniaF707C( F707C *link , char zona , short Sintonia ) {
	if( zona > 7 ) { return( FALSE ); }
	link->modulo.sintonia[zona] = Sintonia;
	if( link->read_sintonia != 0 ) {
		link->read_sintonia[zona] = Sintonia;
	}
	if( link->modulo.estado == true ) {
		return( TRUE );
	} else {
		return( FALSE );
	}
}

//-------------------------------------------------------------------------------

/* Establece la habilitacion o no del SAC de F707C del modulo apuntado
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : modo sera el estado ON u OFF del Sac
*/
short SetEnableF707C( F707C *link , short modo ) {
	link->modulo.enable = modo;
	return( link->modulo.enable );
} 

//-------------------------------------------------------------------------------

/* Establece el Control de la zona del modulo apuntado
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : zona sera el numero de zona dentro del modulo 
         : modo_ctrl determinara el ON u OFF del control de la zona particular
         (NOTA: si se utiliza un valor de zona major a 6 el valor de modo_ctrl se aplicara
         a todas las zonas del modulo)
*/
short SetCtrlF707C( F707C *link , char zona , short modo_ctrl ) {
	short i,ret;
	if( zona > 6 ) {
		for( i = 0 ; i < 7 ; i++ ){
			if( modo_ctrl ) {
				link->modulo.cfg[i].bit.CTRLON = 1;
			} else {
				link->modulo.cfg[i].bit.CTRLON = 0;
			}
			if( link->read_control != 0 ) {
				link->read_control[i] = modo_ctrl & 0x01;
			}
		}
		if( link->modulo.estado == true ) {
			ret = TRUE;
		} else {
			ret = FALSE;
		}
	} else { 
		if( modo_ctrl ) {
			link->modulo.cfg[zona].bit.CTRLON = 1;
		} else {
			link->modulo.cfg[zona].bit.CTRLON = 0;
		}
		if( link->read_control != 0 ) {
			link->read_control[zona] = modo_ctrl & 0x01;
		}
		if( link->modulo.estado == true ) {
			ret = TRUE;
		} else {
			ret = FALSE ;
		}
	}
	return( ret );
}

//-------------------------------------------------------------------------------

/* Establece el modo de control de la zono del modulo apuntado
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : zona sera el numero de zona dentro del modulo 
         : modo_ctrl determinara el modo de trabajo de la zona ( PID o CICLADOR )
         (NOTA: si se utiliza un valor de zona major a 6 el valor de modo_ctrl se aplicara
         a todas las zonas del modulo)
*/
short SetModoF707C( F707C *link , char zona , short modo_ctrl ) {
	short i,ret;
	if( zona > 6 ) {
		for( i = 0 ; i < 7 ; i++ ){
			link->modulo.cfg[i].bit.MODO = modo_ctrl;
			if( link->read_modo != 0 ) {
				link->read_modo[i] = modo_ctrl & 0x03;
			}
		}
	} else { 
		link->modulo.cfg[zona].bit.MODO = modo_ctrl;
		if( link->read_modo != 0 ) {
			link->read_modo[zona] = modo_ctrl & 0x03;
		}
	}
	if( link->modulo.estado == true ) {
		ret = TRUE;
	} else {
		ret = FALSE;
	}
	return( ret );
}

//-------------------------------------------------------------------------------

/* Toma la medicion de temperatura de la zona del modulo apuntado
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : zona sera el numero de zona dentro del modulo 
         : *Temp sera donde se alamacenara el valor de temperatura leido de la zona elegida
*/
short GetTempF707C(  F707C *link , char zona , short *Temp ) {
	if( zona > 7 ) { return( FALSE ); }
	*Temp = link->Temperatura[zona];
	if( link->modulo.estado == true ) {
		return( TRUE );
	} else {
		return( FALSE );
	}
}

//-------------------------------------------------------------------------------

/* Devuelve el estado del modulo
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
   devuelve TRUE o FALSE segun este o no habilitado el modulo
*/
short GetStatusF707C( F707C *link ) {
	if( link->modulo.estado == true ) {
		return( TRUE );
	} else {
		return( FALSE );
	}
}

//-------------------------------------------------------------------------------

/* Toma el estado de los contadores del polling record
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         : *ttmsg sera el destino del valor de mensajes enviados
         : *tterror sera el destino del valor de mensajes que resultaron en error
*/
short GetStadisticF707C( F707C *link , short *ttmsg , short *tterror ) {
	*ttmsg = link->sac.polling->counters.total_msg;
	*tterror = link->sac.polling->counters.total_errors;
	if( link->modulo.estado == true ) {
		return( TRUE );
	} else {
		return( FALSE );
	}
}	

//-------------------------------------------------------------------------------

/* Verifica que la temperatura este dentro del +- rango permitido 
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         :  Range es el valor + -  de temperatura al rededor del setpoint donde se verifica la funcion
         :  modo define si Range es + -  del setpoint o es una temperatura directa
*/
short CheckSecureTemp( F707C *link , short Range , char modo) {
	short ret,i,modulo;
	ret = TRUE;
	for( i = 0 ; i < 7 ; i++ ) {
		if( link->Set_point[i] != 0 ) {
			if( link->stts[i].bit.MED_OK ) {        
				if( modo == 0 ) {
					modulo = link->Temperatura[i] - ( link->Set_point[i] - Range ) ;  
				} else {
					modulo = link->Temperatura[i] - Range  ;  
				}						
				if( modulo < 0 ) {
					ret = FALSE;
				}
			} else {
				if( link->read_modo[i] != CICL_MODE ) {
					ret = FALSE;
				}
			}
		}
	}
	return( ret );
}

//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------

/* Verifica que la temperatura este dentro del +- rango permitido 
   donde : *link sera el puntero al conjunto de parametros del modulo deseado
         :  Range es el valor + -  de temperatura al rededor del setpoint donde se verifica la funcion
         :  modo define si Range es + -  del setpoint o es una temperatura directa
*/
short ServicioSecureTemp( F707C *link , short Range , char modo) {
	short ret,i,modulo;
	ret = TRUE;
	for( i = 0 ; i < 7 ; i++ ) {
		if( link->Set_point[i] != 0 ) {
			if( link->stts[i].bit.MED_OK ) {        
				if( modo == 0 ) {
					modulo = link->Temperatura[i] - ( link->Set_point[i] - Range ) ;  
				} else {
					modulo = link->Temperatura[i] - Range  ;  
				}						
				if( modulo < 0 ) {
					ret = FALSE;
				}
			} else {
				if( link->read_modo[i] != CICL_MODE ) {
					ret = FALSE;
				}
			}
		}
	}
	return( ret );
}

//-------------------------------------------------------------------------------

/* ************************************************************************ */
/* Control de Segundo Corte ----------------------------------------------- */
/* ************************************************************************ */
/* ej.: CTRLalarma( &Zonas1a7 , 2 , SEG_CORT_2 , VENT_2 , R_V_2 );			*/
short CTRLalarma( F707C *link , short ZONA , short SETEO , unsigned short *SALIDA , unsigned short NUMERO ) {
    short ret, modulo;
    ZONA = ZONA - 1;            
	ret = TRUE;
	if(( ZONA >= 0 )&&( ZONA <= 6 )) {  
	    if( link->Set_point[ZONA] != 0 ){			// Verifica que el set point sea distinto de cero (zona habilitada) 
			if( link->stts[ZONA].bit.CTRLON ) {		// Verifica que el control de temp este habilitado
				if( link->stts[ZONA].bit.MED_OK ) {	// Verifica que la termocupla este true
					modulo = link->Temperatura[ZONA] - ( link->Set_point[ZONA] + SETEO ) ;
		    	    if( modulo > 0  ){
    		    	    _bit_set( SALIDA , NUMERO );
	    		    } else {
						modulo = link->Temperatura[ZONA] - ( link->Set_point[ZONA] + SETEO - HIST_ALAMA ) ;
	   	    		    if( modulo < 0 ) {
        	    		    _bit_clear( SALIDA , NUMERO );
		            	}
					}
				} else {
		   		    _bit_clear( SALIDA , NUMERO );
				}
	        } else {
   			    _bit_clear( SALIDA , NUMERO );
			}
    	} else {
   		    _bit_clear( SALIDA , NUMERO );
		}
	} else {
		ret = FALSE;
	}
	return( ret );
}

//-------------------------------------------------------------------------------

/* OverHeatTemp ( puntero a control de temperatura , Rango de temperatura por arriba )
    Verifica si que las zonas de calefaccion no sobrepasen un rango maximo de temperatura
    en el caso de hacerlo devuelve un falso, tambien lo hace si la zona mide mal y no esta en ciclador
    
*/
short OverHeatTemp( F707C *link , short *Set_point , short Range_max ) {
	short ret,i,modulo;
	ret = TRUE;
	for( i = 0 ; i < 7 ; i++ ) {
		if( link->Set_point[i] != 0 ) {
			if( link->stts[i].bit.MED_OK ) {        
				if( link->Temperatura[i] >= ( Set_point[i] + Range_max ) ) {
				    ret = FALSE;
				}
			} else {
				if( link->read_modo[i] != CICL_MODE ) {
					ret = FALSE;
				}
			}
		}
	}
	return( ret );
}

//-------------------------------------------------------------------------------
