#define ALL_ZONE	    9
#define HIST_ALAMA	    2

#define PID_MODE		0
#define ON_OFF_MODE		1
#define CICL_MODE		2
#define NONE_MODE		3

#define TRUE 	true 
#define FALSE	false 

#define _bit_set(x,y)	*x|=y
#define _bit_clear(x,y)	*x&=~y

union _F707C_ctrl{
	struct {
		unsigned short OV_MED_H       :1;	// Estado de Medicion por sobre la tabla de linealizacion
		unsigned short OV_MED_L       :1;	// Estado de Medicion por debajo la tabla de linealizacion
		unsigned short MED_OK         :1;	// Medicion OK
		unsigned short bit_3          :1;
		unsigned short bit_4          :1;
		unsigned short ESTABLE        :1;	// Temperatura Estable
		unsigned short SINTON         :1;	// Control de Auto Sintonia Habilitado
		unsigned short CTRLON         :1;	// Control Proporcional de Salida Habilitado
		unsigned short SINTO_SAVE     :1;	// Aviso para Guardar la Sintonia en Memoria no volatil
		unsigned short SINTO_SAVED_OK :1;	// Flag de Guardado de la Sintonia en Memoria no volatil OK
		unsigned short H_RANGO        :3;	// Histeresis del Modo ON_OFF
		unsigned short POLARIDAD      :1;	// Polaridad de la salida
		unsigned short MODO	        :2;	// Seleccion de Modo de trabajo (PID,CICLADOR,ON_OFF, NONE )
	}bit;
	unsigned short Wfull;
};

union _F707C_jobCONTROL{
	struct {
		unsigned short SETPOINT		:1;	// Modificacion del SetPoint
		unsigned short CTRLON		:1;	// Modificacion del Control 
		unsigned short SINTON		:1;	// Modificacion del auto-sintonia
		unsigned short CERO			:1;	// Modificacion del cero
		unsigned short SPAN			:1;	// Modificacion del span
		unsigned short CURVA		:1;	// Modificacion del curva
		unsigned short NIVELFILTRO	:1;	// Modificacion del nivel del filtro
		unsigned short CTEPROP		:1;	// Modificacion del cte. proporcional
		unsigned short FACTORFUZZY	:1;	// Modificacion del Factor Fuzzy
		unsigned short TSAVESINTO	:1;	// Modificacion del Time Save Sintonia
		unsigned short SINTONIA		:1;	// Modificacion del Sintonia
		unsigned short CICLO		:1;	// Modificacion del Ciclo
		unsigned short MODE_CTRL	:1;	// Modificacion del Modo de Control
		unsigned short POLAR_CTRL	:1;	// Modificacion del Polaridad de Control
		unsigned short HIST_CTRL	:1;	// Modificacion del Histeresis
		unsigned short bit_15		:1;	// Modificacion del *
	}mod;
	unsigned short Wfull;
};
	

struct _F707C{
	char IDF707C;						// Direcion de Esclavo
	short Temperatura[8];				// Temperatura Medida de la zonas
	short Set_point[8];					// Set Point de las zonas registradas (ojo no es de uso)
	union _F707C_ctrl stts[8];					// Status de la zonas
	short Sintonia[8];					// Sintonia
	short *write_temp;
	short *read_setpoint;
	short *read_control;
	short *read_modo;
	short *read_sintonia;
	short *write_stts;
	struct {
		short estado;						// Estado del modulo
		short enable;						// Habilitacion del modulo (si es off estado da ok y la temp = 0) "on_scan"
		short Set_point[8];					// Set point de control
		union _F707C_ctrl cfg[8];			// Control de funcionamiento
		short sintonia[8];					// Sintonia
		union _F707C_jobCONTROL modCTRL[8];	// Registro de Cambio.
	} modulo;
	struct {
		short Error;					// Estado de Error	
		short estado;					// Estado del Poll SAC
		struct _poll_record *polling;	// Polling Record Asociado
	}sac;	
};

typedef struct _F707C F707C;



#define	SAC707C_NO_INITIALIZE	-1

// Inicializa el modulo de Temperatura F707C apuntado
short init_F707C( F707C *link ) ;
// Mantiente el parser de control.
short sac_F707C( F707C *link ) ;

// Establece la habilitacion o no del SAC de F707C del modulo apuntado
short SetEnableF707C( F707C *link , short modo ) ;
// Establece el SetPoint de una zona del modulo apuntado
short SetPointF707C( F707C *link , char zona , short SetPoint ) ;
// Establece el Ciclo de Trabajo de una zona del modulo apuntado
short SintoniaF707C( F707C *link , char zona , short DutyCycle ) ;
// Establece el Control de la zona del modulo apuntado
short SetCtrlF707C( F707C *link , char zona , short modo_ctrl ) ;
// Establece el modo de control de la zono del modulo apuntado
short SetModoF707C( F707C *link , char zona , short modo_ctrl ) ;
// Toma la medicion de temperatura de la zona del modulo apuntado
short GetTempF707C(  F707C *link , char zona , short *Temp ) ;
// Devuelve el estado del modulo
short GetStatusF707C( F707C *link ) ;
// Toma el estado de los contadores del polling record
short GetStadisticF707C( F707C *link , int *ttmsg , short *tterror ) ;
// Verifica que la temperatura este dentro del +- rango permitido 
short CheckSecureTemp( F707C *link , short Range , char modo) ;
// Ventiladores alarma etc.
short CTRLalarma( F707C *link , short ZONA , short SETEO , unsigned short *SALIDA , unsigned short NUMERO ) ;
// Verifica que las zonas no superen un maximo de temperuta por sobre el setpoint
short OverHeatTemp( F707C *link , short *Set_point , short Range_max ) ;