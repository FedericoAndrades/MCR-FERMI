#include "ModbusRTU.h"

#define MOTOROLA false
#define RS_485 true
//#define PRN_DEBBUG true

// definir RTS activo Alto o Bajo segun se use Rs485 o Rs232 en el Port
// de comunicacion.

void ModbusMaster::clear_rts_state ( void ) {
#ifdef PRN_DEBBUG
	Serial.print("RTS clear ");
	Serial.println( RTS_pin );
#endif
    pinMode( RTS_pin , OUTPUT );
	if( RTS_mode & 0x01 ) {
		digitalWrite( RTS_pin , LOW );
	} else {
		digitalWrite( RTS_pin , HIGH );
	}
}

void ModbusMaster::set_rts_state ( void ) {
#ifdef PRN_DEBBUG
	Serial.print("RTS set ");
	Serial.println( RTS_pin );
#endif
    pinMode( RTS_pin , OUTPUT );
	if( RTS_mode & 0x01 ) {
		digitalWrite( RTS_pin , HIGH );
	} else {
		digitalWrite( RTS_pin , LOW );
	}
}

// limpiar la fifo de entrada tomando todos los caracteres que haya
void ModbusMaster::flush_rx( void ) {
	unsigned int aux;
	int cont;
	cont = 128;
	while(( Comm->available() )&&( cont > 0 )) {
		cont--;// proteccion contra errores de lectura progresivos
		aux = Comm->read();
		parser.utime.eom = timers.eom;
	}
}

/*----------------------------------------------------------------------*/
/* Aqui  rutinas de calculo y verificacion de crc_16  8-julio-97   		*/
/*----------------------------------------------------------------------*/
/* @@@ ATENCION !!! orden de bytes Modbus es Motorola salvo para Crc
   address, length y data  MSB (hi) primero, LSB (lo) despues;
   En Crc: crc LSB (lo) primero, MSB (hi) despues
   Largo es cantidad de elemementos no pos. de array, esto es es 1 mas
   de la posicion; asi bb[0]...bb[n-1] corresponde un largo n
*/
#define G_POL 0xA001
/* 1010 0000 0000 0001 binario */

unsigned short ModbusMaster::calcular_crc16(unsigned char buff[], short largo)
{
	unsigned short A;
	unsigned short AH,AL;
	short i,j,cy;

	A = 0xffff;
	for(i=0; i<largo; i++) {
		AL=A & 0x00ff; AH=A & 0xff00;
		AL=(unsigned short)buff[i] ^AL;
		A=AH + AL;
		for(j=0; j<8; j++) {
			cy=A & 0x0001; /* tomo futuro carry antes de shift */
			A=(unsigned short)(A>>1);
			if(cy) A=(unsigned short)(G_POL ^ A);
		}
	}
	return( A );
}

short ModbusMaster::check_crc16( unsigned char *buff, short largo )
{
	unsigned short crc_calc;
	unsigned short crc_en_buffer;

	if( largo < 2 ) {
		return ( false ); /* si no puedo calcular nada */
	}

	crc_en_buffer = (buff[largo-1]<<8) + buff[largo-2]; /* orden=lo,hi */
	crc_calc = calcular_crc16(buff, largo-2);
	if( crc_calc == crc_en_buffer ) {
		return( true );
	} else {
		return( false );
	}
}

/*------------------------------------------------*/
int ModbusMaster::begin( void ) {
	return( begin( baudrate ,  RTS_pin ) );
}

int ModbusMaster::begin( unsigned long baud ) {
	baudrate = baud;
	return( begin( baudrate ,  RTS_pin ) );
}

int ModbusMaster::begin( unsigned long baud , int rts_pin ) {
	int i;

	RTS_pin = rts_pin;
	baudrate = baud;

    /* baud rate Uart, muy importante !!, fijo 8 bits, 1 stop, no paridad */
   	Comm->begin( baudrate , SERIAL_8N1 );

	if( ! Comm ) {
		// Aqui poner errores de open. Ver. Federico
		return ( false );
	}
	
	if( polling_record == NULL ) {
		return ( false );
	}
	if( polling_large <= 0 ) {
		return ( false );
	}

	i = baudrate / 100 ;
   	switch( i ) {
     	case  12 : timers.eom = 32*MULTT; break;//  1200 
     	case  24 : timers.eom = 16*MULTT; break;//  2400
     	case  48 : timers.eom =  8*MULTT; break;//  4800
        case  96 : timers.eom =  4*MULTT; break;//  9600
        case 192 : timers.eom =  2*MULTT; break;// 19200
        case 384 : timers.eom =  2*MULTT; break;// 38400
        case 576 : timers.eom =  1*MULTT; break;// 57600
        default  : timers.eom =  4*MULTT; break;
	}

    /* tiempos fijos por ahora, se pueden parametrizar en linea */
    timers.rts_time_on=7;  	/* tiempo de rts_on en centesimas de seg */
    timers.rts_time_off=1; 	/* tiempo de rts_off en centesimas de seg */
    timers.rpt=20;     		/* tiempo de espera antes de repetir un pedido */
    timers.tx_time_out=200;  		/* 2 segundos de time out de transmision */
	timers.rx_time_out=200;		
	parser.n_retry=3;

	parser.nr = 0;

	poll_activo = false;

	clear_rts_state(); // Rts OFF
	
	parser.estado_comm = LIBRE ;
	parser.poll_flag = false ;
		
	for( i = 0 ; i < polling_large ; i++ ) {
		polling_record[i].pflag.Wfull = 0;
		polling_record[i].parser.ptimer = 0;
		polling_record[i].pr_error = 0;
		polling_record[i].counters.total_msg = 0;	  		// contadores de mensajes totales ( podrian no inicializarse )
		polling_record[i].counters.total_errors = 0;	  	// contadores de errores ( podrian no inicializarse )
		polling_record[i].counters.time_out_errors = 0;
		polling_record[i].counters.crc_errors = 0;
	}
    return ( true );
}

int ModbusMaster::end() {
	polling_record = NULL;
	polling_large = 0;
    
	clear_rts_state(); // Rts OFF
    Comm->end();
	
	parser.estado_comm = MBM_COMM_CLOSE ;
	parser.poll_flag = false;
		
    return ( true );
}


short ModbusMaster::tomar_datos_read( ) {
	short i,k,res, nr;
	unsigned char *p;

	/* primero veo si CRC ok*/
	if( check_crc16(parser.rx_data,parser.ixp) == false ) {
		return( MBM_BAD_CRC );
	}

	// nr: numero de record de polling ciclado por el parser_mbm/
	nr = parser.nr;

	/* tomo y verifico rtu, function y rx_bc */
	if( parser.rx_data[0] != polling_record[nr].station ) {
		return( MBM_BAD_RTU_ADDR ); 
	}
	/* si es la direccion de RTU sigo */
	
	if( parser.rx_data[1] != polling_record[nr].function ) {
		if( parser.rx_data[2] & 0x80 ) {
			switch( parser.rx_data[2] ) {
				case 1 : res=ILLEGAL_FUNCTION; 		break;
				case 2 : res=ILLEGAL_DATA_ADDRESS; 	break;
				case 3 : res=ILLEGAL_DATA_VALUE; 	break;
				case 6 : res=BUSY_REJECT_MSG; 		break;
				default	: res=ILLEGAL_FUNCTION; 	break;
			}
			return res;
 	    } else {
			return( MBM_BAD_RET_FUNC );
		}
	}
	/* aqui solo puewde ser una respuesta a comandos de read (Holding o Input) */
	/* calculo numero de bytes por tipo de datos, fijo en INTEGER */

	k = 2;
	if( parser.rx_data[2] > (polling_record[nr].length * k) ) {
		return( MBM_BAD_RET_BCOUNT );
	}
	
	p = polling_record[nr].data;

	for( i = 0 ; (i<parser.rx_data[2]/k)&&(i<polling_record[nr].N_data) ; i++ ) {
		/* vienen en orden de memoria HI-LO  de Modbus, convertir segun CPU */
#if	MOTOROLA
		if(( *p != parser.rx_data[3+i*k] )||( *(p+1) != parser.rx_data[4+i*k] )) {
			if ( polling_record[nr].pflag.bit.new_data ) {
				polling_record[nr].pflag.bit.over_run = 1;
			}
			polling_record[nr].pflag.bit.new_data = 1; 
			*p++ = parser.rx_data[3+i*k]; /* orden de memoria HI-LO  Motorola 	 */
			*p++ = parser.rx_data[4+i*k];
		} else {
			p += 2;
		}
#else
		if(( *p != parser.rx_data[4+i*k] )||( *(p+1) != parser.rx_data[3+i*k] )) {
			if ( polling_record[nr].pflag.bit.new_data ) {
				polling_record[nr].pflag.bit.over_run = 1;
			}
			polling_record[nr].pflag.bit.new_data = 1; 
			*p++ = parser.rx_data[4+i*k]; /* orden de memoria HI-LO  Motorola 	 */
			*p++ = parser.rx_data[3+i*k];
		} else {
			p += 2;
		}
#endif

	}
	return( MBM_COMMAND_OK );
}

/*------------------------------------------------*/
short ModbusMaster::verificar_respuesta_write() {
	short i,k,res,nr;
	unsigned char *p;
	unsigned char Hi,Lo;
/* primero veo si CRC ok*/

	if( check_crc16(parser.rx_data,parser.ixp) == false ) {
		return( MBM_BAD_CRC );
	}

	/* tomo y verifico rtu, function y rx_bc */
	
	nr = parser.nr;
	// nr: numero de record de polling ciclado por el parser_mbm/

	if( parser.rx_data[0] != polling_record[nr].station ) {
		return( MBM_BAD_RTU_ADDR );
	}
	
	/* si es la direccion de RTU sigo */
	if( parser.rx_data[1] != polling_record[nr].function ) {
		if( parser.rx_data[2] & 0x80 ) {
			switch(parser.rx_data[2]) {
				case 1 : res=ILLEGAL_FUNCTION; 		break;
				case 2 : res=ILLEGAL_DATA_ADDRESS; 	break;
				case 3 : res=ILLEGAL_DATA_VALUE; 	break;
				case 6 : res=BUSY_REJECT_MSG; 		break;
				default	: res=ILLEGAL_FUNCTION; 	break;
			}
			return( res );
 	    } else {
			return( MBM_BAD_RET_FUNC );
		}
	}

	/* aqui ver si fue una funcion de lectura o una de write ( 1, multiple o 4X ) */
	/* veo si coincide el registro que devuelve */

	Hi = ( polling_record[nr].address & 0xFF00 ) >> 8 ;
	Lo = polling_record[nr].address&0xFF;
	 /* orden de buffer datos modbus HI-LO  Motorola 	 */
	
	if(( Hi != parser.rx_data[2] )||( Lo != parser.rx_data[3] )) {
		return( MBM_BAD_WRITE_RPLY );
	}

	/* Tipo de datos, fijo en INTEGER */
	
	res = MBM_COMMAND_OK;
	switch(polling_record[nr].function) {
		case WRITE_HOLDING_REGISTER:
			/* comparar lo escrito con los datos en poll record */
			/* vienen en orden de memoria HI-LO  de Modbus, convertir segun CPU */
#if	MOTOROLA  /* orden de memoria HI-LO  Motorola 	 */
			if(polling_record[nr].data[0]!=parser.rx_data[4]) res = MBM_BAD_WRITE_RPLY;
			if(polling_record[nr].data[1]!=parser.rx_data[5]) res = MBM_BAD_WRITE_RPLY;
#else 		/* orden de memoria LO-HI  Intel */
			if(polling_record[nr].data[0]!=parser.rx_data[5]) res = MBM_BAD_WRITE_RPLY;
			if(polling_record[nr].data[1]!=parser.rx_data[4]) res = MBM_BAD_WRITE_RPLY;
#endif
			break;
		case WRITE_MULTIPLE_HOLDING_REGISTERS:
			/* comparar numero devuelto en el buffer con el numero de registros en poll record */
			Hi = ( polling_record[nr].length & 0xFF00 ) >> 8;
			Lo = polling_record[nr].length & 0xFF;
 			/* orden de buffer datos modbus HI-LO  Motorola 	 */
			if(( Hi!=parser.rx_data[4] )||( Lo!=parser.rx_data[5] )) res = MBM_BAD_WRITE_RPLY;
			break;
		case WRITE_MASK_4X_REGISTER:
			p = polling_record[nr].data;
			/* comparar lo escrito con los 2 datos ( and msk y or msk ) en poll record */
			/* vienen en orden de memoria HI-LO  de Modbus, convertir segun CPU */
#if	MOTOROLA  /* orden de memoria HI-LO  Motorola 	 */
			if(( *p++!=parser.rx_data[4] )||( *p++!=parser.rx_data[5] )) res = MBM_BAD_WRITE_RPLY;
			if(( *p++!=parser.rx_data[6] )||( *p++!=parser.rx_data[7] )) res = MBM_BAD_WRITE_RPLY;
#else 		/* orden de memoria LO-HI  Intel */
			if(( *p++!=parser.rx_data[5] )||( *p++!=parser.rx_data[4] )) res = MBM_BAD_WRITE_RPLY;
			if(( *p++!=parser.rx_data[7] )||( *p++!=parser.rx_data[6] )) res = MBM_BAD_WRITE_RPLY;
#endif
			break;
		default:
			res = MBM_DRIVER_ERROR; 
			break;
	}
	return( res );
}
/* ----- Fede 05/07/04 ----- */

/* ------------------------------------------------ */
short ModbusMaster::service() {
	unsigned char c;
	unsigned char *p;
	unsigned short crc,aux;
	short i,nr;
	unsigned char start_hi, start_lo, length_hi, length_lo, data_hi, data_lo;

	/* aqui parser de estado de comm */
	if( parser.nr >= polling_large ) { //Verifica que el nr no este fuera de rango
		parser.nr = 1;
	}
	nr = parser.nr;
	// nr: numero de record de polling ciclado por el parser_mbm
	// save_nr: numero de record de polling ciclado por el parser_mbm
	// en curso, salvado al usar el polling record 0 prioritario
	switch ( parser.estado_comm ) {
	   	case LIBRE :
			/* primero ver el poll record 0 que es el de los comando de una sola vez
		   		y prioritarios, o sea saltan el esquema de ronda */
			/* llegue por ptimer==0 */
			if(( polling_record[0].pflag.bit.on_poll )&&( polling_record[0].pflag.bit.tag )&&( polling_record[0].parser.ptimer==0 )) {
				parser.estado_comm=ARMAR_PEDIDO;
				parser.utime.retry = parser.n_retry;
				parser.save_nr = parser.nr;
				parser.nr = nr = 0;	
				polling_record[nr].pflag.bit.polling = 1;	// indicacion de record en polling, lo baja el fin poll
				polling_record[nr].counters.total_msg+=1; // incrementar contador de mensajes

				// nr== -> procesar comando fuera de poll 
			} else if((poll_activo )&&( polling_record[nr].pflag.bit.on_poll )&&( polling_record[nr].pflag.bit.tag )&&( polling_record[nr].parser.ptimer == 0 )) {
#if PRN_DEBBUG
				Serial.print("\n Inicio Pedido pollingrecord:");
				Serial.print(nr,HEX);
				Serial.print(" ");
				Serial.print( polling_record[nr].pflag.bit.on_poll );
				Serial.print(" ");
				Serial.print( polling_record[nr].pflag.Wfull , HEX );
				Serial.println();
#endif

				parser.estado_comm=ARMAR_PEDIDO;
				parser.utime.retry = parser.n_retry;
				polling_record[nr].pflag.bit.polling = 1;	// indicacion de record en polling, lo baja el fin poll
				polling_record[nr].counters.total_msg+=1; // incrementar contador de mensajes
			} else {
				parser.nr++;
				if( parser.nr >= polling_large ) {
					parser.nr = 1;
				}
				/* salto poll sin definir y espero el primer ptimer que de cero */
			}
		   	break;
			
		case ARMAR_PEDIDO : /* armar buffer de pedido */
 			/* calculo function, start_hi/lo, length_hi/lo, crc, etc. en buffer tx */
			parser.poll_flag=true; /* Indicacion de ciclo de polling */

			if(polling_record[nr].length > polling_record[nr].N_data ) {
				parser.err_comm = MBM_BAD_POOL_LEN; 
				parser.estado_comm = POLL_ERROR; /* salir del parser */
			 	break;
			}
			/* aqui armar comando, esta asegurado que no escriba mas lo que
			   permite el buffer tx_data (ver *.h) */
		
			p = parser.tx_data; 					parser.largo_tx=0;
			*p++ = polling_record[nr].station; 		parser.largo_tx++;
			*p++ = polling_record[nr].function; 	parser.largo_tx++;
			start_hi =(polling_record[nr].address & 0xff00)>>8;
			start_lo = polling_record[nr].address & 0xff;
			*p++ = start_hi; 						parser.largo_tx++;
			*p++ = start_lo; 						parser.largo_tx++;
			length_hi = (polling_record[nr].length & 0xff00)>>8;
			length_lo = polling_record[nr].length & 0xff;

		/* aqui ver si es un comando de lectura o uno de escritura */
			parser.err_comm = MBM_COMMAND_OK;
			switch(polling_record[nr].function) {
				/* read's */
				case READ_HOLDING_REGISTERS:
				case READ_INPUT_REGISTERS:
					*p++=length_hi; parser.largo_tx++;
					*p++=length_lo; parser.largo_tx++;
					break;
	 			/* Write's */
 				case WRITE_HOLDING_REGISTER:
#if	MOTOROLA
					/* orden Motorola de datos en memoria */
					data_hi=polling_record[nr].data[0]; 
					data_lo=polling_record[nr].data[1];
#else
	 				/* orden Intel de datos en memoria */
					data_hi=polling_record[nr].data[1]; 
					data_lo=polling_record[nr].data[0];
#endif
					*p++=data_hi; parser.largo_tx++;
					*p++=data_lo; parser.largo_tx++;
					break;
				case WRITE_MULTIPLE_HOLDING_REGISTERS:
					*p++=length_hi; parser.largo_tx++;
					*p++=length_lo; parser.largo_tx++;
					*p++=polling_record[nr].length*2; parser.largo_tx++; /* byte count*/

					for ( i = 0 ; i<polling_record[nr].length ; i++ ) {
#if	MOTOROLA			/* orden Motorola de datos en memoria */
						data_hi=polling_record[nr].data[0+i*2]; 
						data_lo=polling_record[nr].data[1+i*2];
#else			 		/* orden Intel de datos en memoria */
						data_hi=polling_record[nr].data[1+i*2]; 
						data_lo=polling_record[nr].data[0+i*2];
#endif		
						*p++=data_hi; 		parser.largo_tx++;
						*p++=data_lo; 		parser.largo_tx++;
					}
					break;
				case WRITE_MASK_4X_REGISTER:
#if	MOTOROLA
/* orden Motorola de datos en memoria */
					data_hi=polling_record[nr].data[0]; 
					data_lo=polling_record[nr].data[1];
					*p++=data_hi; 		parser.largo_tx++;
					*p++=data_lo; 		parser.largo_tx++;
					data_hi=polling_record[nr].data[2]; 
					data_lo=polling_record[nr].data[3];
					*p++=data_hi; 		parser.largo_tx++;
					*p++=data_lo; 		parser.largo_tx++;
#else
	 		/* orden Intel de datos en memoria */
					data_hi=polling_record[nr].data[1]; 
					data_lo=polling_record[nr].data[0];
					*p++=data_hi; 		parser.largo_tx++;
					*p++=data_lo; 		parser.largo_tx++;
					data_hi=polling_record[nr].data[3]; 
					data_lo=polling_record[nr].data[2];
					*p++=data_hi; 		parser.largo_tx++;
					*p++=data_lo; 		parser.largo_tx++;
#endif
					break;
				default:
					parser.err_comm= MBM_DRIVER_ERROR;
					break;
			}
			if( parser.err_comm != MBM_COMMAND_OK ) { 
				parser.estado_comm=POLL_ERROR; 
				break;
			} /* salir del parser */
			
			crc = calcular_crc16(parser.tx_data,parser.largo_tx);
			*p++=(unsigned char)(crc & 0x00ff); 			parser.largo_tx++;
			*p++=(unsigned char)( (crc & 0xff00) >>8 ); 	parser.largo_tx++;

			parser.estado_comm=TX_PEDIDO;
			// Activar RTS y esperar tiempo de rts_on
			parser.utime.timer = timers.rts_time_on;
			set_rts_state(); // Rts ON
		   	break;
/* -----------------------------------------------------------------*/

	   	case TX_PEDIDO : /* esperar tiempo de rts_on y luego enviar buffer tx */
			if( parser.utime.timer == 0 ) {
#if PRN_DEBBUG
				Serial.println("\n Inicia Tx Pedido ");
#endif
			/* mando Buffer */
				flush_rx( );
			  /* mando comando modbus de polling (nr) */
			  /* send(tx_buffer, largo_tx) */
			  	for( i = 0 ; i < parser.largo_tx ; i++ ) {
			  		aux = parser.tx_data[i];
					Comm->write( aux );
				}
			  	parser.utime.time_out=timers.tx_time_out; // preparo time out TX
			  	parser.estado_comm = ESPERA_TX;
			}
	   		break;
	   	case ESPERA_TX : // aqui espero que el bios envie el mensaje
			// ver si time_out de TX
            Comm->flush();
			if( true )  { 		// @@@ usar rutina de bios tipo Ioctrl(device)
#if PRN_DEBBUG
				Serial.println("\n Fin Tx Pedido ");
#endif
			    parser.utime.timer = timers.rts_time_off; /* recargar timer */
				parser.estado_comm = POST_TX;
			} else	{ // procesar time out TX
	 			if( parser.utime.time_out == 0 ) { // aqui time out TX
					if( parser.utime.retry-- ) { 
						parser.estado_comm=REINTENTO_POLL; 
					} else { 
						parser.estado_comm=POLL_ERROR; 
						parser.err_comm= MBM_TIME_OUT;
					}
				}
 			}
   			break;
	   	case POST_TX : /* esperar tiempo de rts_off y baja rts */
			if( parser.utime.timer == 0 ) {
				parser.estado_comm=ESPERA_RX_DATA;
				clear_rts_state(); // Rts OFF
				parser.utime.time_out=timers.rx_time_out; 
				parser.ixp=0;
	   		}
			break;
	   	case ESPERA_RX_DATA : /* esperar primer caracter */
			if( parser.utime.time_out == 0 ) {
#if PRN_DEBBUG
				Serial.println("\n Respuesta Esclavo Time Out");
#endif
				if( parser.utime.retry-- ) { 
#if PRN_DEBBUG
					Serial.println("\n TimeOut Reintento");
#endif
					parser.estado_comm=REINTENTO_POLL; 
				} else { 
#if PRN_DEBBUG
					Serial.println("\n Poll Error TimeOUT ");
#endif
					parser.estado_comm=POLL_ERROR; 
					parser.err_comm= MBM_TIME_OUT;
				}
		    } else {
			  	if ( Comm->available() ) {
	    			// eom_timer=0 si no se recibio char en 3 1/2 char de tiempo
					if( parser.ixp < MAXBUF ) { /* ver limite de rx_data */
						// aqui ver si los datos son nuevos antese de grabarlos */
						aux = Comm->read();
/*						if(c != parser.rx_data[parser.ixp]) {
						}*/ 
							// guardo caracter en buffer y marco NEW_DATA
							// que solo es bajado por el SAC
							// si no leyo el Sac los datos nuevos
						parser.rx_data[parser.ixp++] = aux;
						parser.utime.eom = timers.eom;
						// recargo timer si no lo hizo la interfaz serie
					} else {
			 			parser.err_comm=MBM_BUFFER_OVERFLOW;
						parser.estado_comm=POLL_ERROR;
					}
				} else {
					if((parser.utime.eom == 0) && parser.ixp ) {
#if PRN_DEBBUG
						Serial.print("Responde Escalvo ");
						Serial.print(timers.eom);
						Serial.print(",");
						Serial.print(parser.ixp );
						Serial.print(":");
						for( i = 0 ; i < parser.ixp ; i++ ) {
							Serial.print( parser.rx_data[i] );
						}
						Serial.println();
#endif

						switch(polling_record[nr].function) {
							/* read's */
							case READ_HOLDING_REGISTERS:
							case READ_INPUT_REGISTERS:
								parser.err_comm = tomar_datos_read();
								break;
						 		/* Write's */
 							case WRITE_HOLDING_REGISTER:
							case WRITE_MULTIPLE_HOLDING_REGISTERS:
							case WRITE_MASK_4X_REGISTER:
								parser.err_comm = verificar_respuesta_write();
								break;
							default:
			 					parser.err_comm= MBM_DRIVER_ERROR;
			 					break;
						}
						if( parser.err_comm == MBM_COMMAND_OK ) {
#if PRN_DEBBUG
							Serial.println("\n Respuesta OK ");
#endif
		 					parser.estado_comm = FIN_POLL; /* por ahora fin_poll */
						} else {
#if PRN_DEBBUG
							Serial.print("Respuesta Error ");
							Serial.println(parser.err_comm);
#endif
							if( parser.utime.retry-- ) { 
#if PRN_DEBBUG
								Serial.println("\n Reitento ");
#endif
								parser.estado_comm=REINTENTO_POLL;
							} else { 
#if PRN_DEBBUG
								Serial.println("\n Poll Error ");
#endif
								parser.estado_comm=POLL_ERROR;
							}
						}
					}
				}
			}
			break;
		case REINTENTO_POLL :
			parser.estado_comm = ESPERA_RPT;
			parser.utime.timer = timers.rpt;
			// aqui si hace falta poner otros contador de reintentos 
			// aqui indicar en pflag Retries??
		   	break;
	   case ESPERA_RPT :
			if( parser.utime.timer == 0 ) {
				parser.estado_comm=ARMAR_PEDIDO;
			}
		   	break;

	   case POLL_ERROR : /* err_comm es puesto por el estado de donde salio error */
			polling_record[nr].pr_error = parser.err_comm;
			polling_record[nr].counters.total_errors++;
			
			if( parser.err_comm == MBM_TIME_OUT ) {
				polling_record[nr].counters.time_out_errors++;
			}
			if( parser.err_comm == MBM_BAD_CRC ) {
				polling_record[nr].counters.crc_errors++;
			}
			// aqui si hace falta poner otros contadores y discirminarlos 
			polling_record[nr].pflag.bit.error_poll = 1; // lo baja el SAC
			polling_record[nr].pflag.bit.on_poll = 0;
			parser.estado_comm=FIN_POLL;
		   	break;

	   case FIN_POLL :
			if( nr == 0 ) {
				parser.nr = parser.save_nr; /* recupero poll record en curso, depsues de un comando prioritrario */
				polling_record[0].pflag.bit.on_poll = 0;  /* saco de poll, pr[0] siempre es DO_ONE */
			} else {
				/* si esta marcado DO_ONE saco de poll */
				if( polling_record[nr].pflag.bit.do_one ) {
					polling_record[nr].pflag.bit.on_poll = 0;
				}
			}
			polling_record[nr].parser.ptimer = polling_record[nr].ptimer_reload; //* reload timer de polling
			polling_record[nr].pr_error = parser.err_comm;
			parser.poll_flag = false; 		// Indicacion de fin ciclo de polling global
			polling_record[nr].pflag.bit.polling = 0;	// bajar estado  de poling
			polling_record[nr].pflag.bit.ready = 1; 	// Indicacion de fin ciclo de polling en pflag
			// incremento proximo poll_record
			parser.nr++;
			if( parser.nr >= polling_large ) {
				parser.nr = 1;
			}
			parser.utime.timer = timers.rts_time_off;;
			parser.estado_comm = FIN_POLL_TOUT;
	   		break;
	   	case FIN_POLL_TOUT:
			if( parser.utime.timer == 0 ) {
				parser.estado_comm = LIBRE;
			}
		   	break;
	   		
	   	default: 
	   		parser.estado_comm=POLL_ERROR; 
			parser.err_comm= MBM_DESCONOCIDO;
	   		break;
	}
	return( parser.estado_comm );
}

// Esta funcion debe llamarse cada 1mS.
short  ModbusMaster::pollingtime () {
	short i;
	parser.utime.pre++;
	if( parser.utime.eom ) parser.utime.eom--;
	if( parser.utime.timer ) parser.utime.timer--;
	if( parser.utime.pre >= 10 ) {
		//Serial.print("MBpt:");
		//Serial.print(polling_large);
		//Serial.print(" ");
		//Serial.print(polling_record[1].parser.ptimer);
		//Serial.println();
		parser.utime.pre = 0;
		if( parser.utime.time_out ) parser.utime.time_out--;
		if(( polling_record != NULL )&&( polling_large > 0 )) {
			for( i = 0 ; i < polling_large ; i++ ) {
				if( polling_record[i].parser.ptimer ) {
					polling_record[i].parser.ptimer--;
				}
			}
		}
	}
	return(i);
}  