/*
 *  USB MSC Service + Fat on NVMFlashDisk
 */

#include <SdFat.h>
#include "../QSPImem/Adafruit_SPIFlash.h"
#include <Adafruit_TinyUSB.h>

void USBMSC_setup ( void ) ;

void USBMSC_ready( bool ready );

void FLASHmem_setup ( void );

void enableWREN ( void ) ;

void globalUnlockProtection( void ) ;

void readBlockProtectionRegister( void ) ;

void writeBlockProtectionRegister( void ) ;

int32_t msc_read_cb (uint32_t lba, void* buffer, uint32_t bufsize) ;

int32_t msc_write_cb (uint32_t lba, uint8_t* buffer, uint32_t bufsize) ;

void msc_flush_cb (void) ;

void USBMSC_enable ( bool mode );