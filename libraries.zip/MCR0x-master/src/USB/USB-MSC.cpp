/*
 *  USB MSC Service + Fat on NVMFlashDisk
 */

#include "USB-MSC.h"

Adafruit_FlashTransport_QSPI flashTransport;
Adafruit_SPIFlash flash(&flashTransport);

FatFileSystem RCFfatfs;

// Flash SST26F064B:
#define SST26F064B                                                              \
  {                                                                             \
    .total_size = (1UL << 23), /* 8 MiB */                                      \
        .start_up_time_us = 5000, .manufacturer_id = 0xbf,                      \
    .memory_type = 0x26, .capacity = 0x43, .max_clock_speed_mhz = 80,           \
    .quad_enable_bit_mask = 0x02, .has_sector_protection = false,               \
    .supports_fast_read = true, .supports_qspi = true,                          \
    .supports_qspi_writes = true, .write_status_register_split = true ,         \
    .single_status_byte = false, .is_fram = false,                              \
  }

static const SPIFlash_Device_t RCFflash_devices[] = {
    SST26F064B,
};

const int flashDevices = 1;

// USB Mass Storage object
Adafruit_USBD_MSC usb_msc;

void USBMSC_setup ( void )
{

  FLASHmem_setup();

  // Set disk vendor id, product id and revision with string up to 8, 16, 4 characters respectively
  usb_msc.setID("FERMI.CE", "External Flash", "1.0");
  // Set callback
  usb_msc.setReadWriteCallback(msc_read_cb, msc_write_cb, msc_flush_cb);
  // Set disk size, block size should be 512 regardless of spi flash page size
  usb_msc.setCapacity(flash.size()/512, 512);
  // MSC is ready for read/write
  usb_msc.setUnitReady(true);

  usb_msc.begin();

}

void USBMSC_ready( bool ready )
{
//  usb_msc.setUnitReady( ready );
}

void FLASHmem_setup ( void )
{
  flash.begin(RCFflash_devices, flashDevices);

  enableWREN();
  readBlockProtectionRegister();
  writeBlockProtectionRegister();

  // Init file system on the flash
  RCFfatfs.begin(&flash);
  // First call begin to mount the filesystem.  Check that it returns true
  // to make sure the filesystem was mounted.
  if ( !RCFfatfs.begin(&flash) ) {
    Serial.println("Error, failed to mount newly formatted filesystem!");
    Serial.println("Was the flash chip formatted with the SdFat_format example?");
    while(1) yield();
  }
  Serial.println("Mounted filesystem!");
}

void enableWREN( void )
{
  uint8_t buff[2];
  do {
    flashTransport.readCommand( SFLASH_CMD_READ_STATUS , &buff[0] , 1 );
  } while( buff[0] & 0x01 );
  flashTransport.readCommand( SFLASH_CMD_READ_STATUS2 , &buff[1] , 1 );
  flashTransport.runCommand( SFLASH_CMD_WRITE_ENABLE );
  do {
    flashTransport.readCommand( SFLASH_CMD_READ_STATUS , &buff[0] , 1 );
  } while( buff[0] & 0x01 );
  flashTransport.readCommand( SFLASH_CMD_READ_STATUS2 , &buff[1] , 1 );
}
void globalUnlockProtection( void )
{
  uint8_t buff[2];
  flashTransport.runCommand( 0xCE );
}

void readBlockProtectionRegister( void )
{
  uint8_t buff[20];
  flashTransport.readCommand( 0x72, buff, 18);
}

void writeBlockProtectionRegister( void )
{
  uint8_t buff[20];
  for(int i = 0 ; i < 18 ; i++ ) {
    buff[i] = 0;
  }
  flashTransport.writeCommand( 0x42, buff, 18);
}

// Callback invoked when received READ10 command.
// Copy disk's data to buffer (up to bufsize) and 
// return number of copied bytes (must be multiple of block size) 
int32_t msc_read_cb (uint32_t lba, void* buffer, uint32_t bufsize)
{
  // Note: SPIFLash Bock API: readBlocks/writeBlocks/syncBlocks
  // already include 4K sector caching internally. We don't need to cache it, yahhhh!!
  return flash.readBlocks(lba, (uint8_t*) buffer, bufsize/512) ? bufsize : -1;
}

// Callback invoked when received WRITE10 command.
// Process data in buffer to disk's storage and 
// return number of written bytes (must be multiple of block size)
int32_t msc_write_cb (uint32_t lba, uint8_t* buffer, uint32_t bufsize)
{
  digitalWrite(LED_BUILTIN, HIGH);

  // Note: SPIFLash Bock API: readBlocks/writeBlocks/syncBlocks
  // already include 4K sector caching internally. We don't need to cache it, yahhhh!!
  return flash.writeBlocks(lba, buffer, bufsize/512) ? bufsize : -1;
}

// Callback invoked when WRITE10 command is completed (status received and accepted by host).
// used to flush any pending cache.
void msc_flush_cb (void)
{
  // sync with flash
  flash.syncBlocks();

  // clear file system's cache to force refresh
  RCFfatfs.cacheClear();

  //changed = true;

  digitalWrite(LED_BUILTIN, LOW);
}

void USBMSC_enable ( bool mode ) 
{
  // MSC is ready for read/write
  //usb_msc.setUnitReady(mode);
}
