/* Enco Control Module */
#include "NCP0x.h"
#include "ENCOctrl.h"

// Inicializacion del Enco --------------------------------------------------------------------
void ENCOs_buffer::init_enco( defENCO *defineENCOs ) 
{
	char i,j, buffer[10];
	j = 0;
	Device->LoadExecCmd( ENCO_NODE , this );
	
	while( defineENCOs->IDnodo != 0 ) {
		buffer[0] = defineENCOs->IDnodo;
		buffer[1] = defineENCOs->OFFSET_ENCODER; 
		Device->gen_msg( 0 , 0 , ENCO_NODE , ENCO_SETUP , buffer , 2 );// Send Setup del ENCOs
		for( i = 0 ; i < 4 ; i++ ) {
			Encoders[j].Contador_Posicion = defineENCOs->Contador_Posicion[i];
			Encoders[j].Encoder_error = defineENCOs->Encoder_error[i];
			j++;
		}
		defineENCOs++;
	}

}
// --------------------------------------------------------------------------------------------

// Reset Individual de ENCODERS ---------------------------------------------------------------
void ENCOs_buffer::rst_enco( char id_enco ) 
{
	if( id_enco < N_ENCODERS ) {
		*Encoders[ id_enco ].Encoder_error = 0;
		*Encoders[ id_enco ].Contador_Posicion = 0;
		Device->gen_msg( 0 , 0 , ENCO_NODE , ENCO_RESET_THIS , &id_enco , 1 );// Send Resetthis del ENCOs
	}
}
// --------------------------------------------------------------------------------------------

// Atencion Comandos NCP0x --------------------------------------------------------------------
void ENCOs_buffer::ExecCmd4this( char COMANDO , char *datos )
{
	char buffer[7];
	char i;

	switch( COMANDO ) {
		case ENCO_ERROR: // Estado de Error del Encoder --------------------------------------
			if( datos[1] < N_ENCODERS ) {
				*Encoders[ datos[1] ].Encoder_error = *((int*)&datos[3]) ;
			}
			break;
		case ENCO_INC_CONT: // Incremento contador encoder -----------------------------------
			if( datos[1] < N_ENCODERS ) {
				*Encoders[ datos[1] ].Contador_Posicion += *((int*)&datos[3]) ;
			}
			break;
	}
}
// ---------------------------------------------------------------------------------------------------

