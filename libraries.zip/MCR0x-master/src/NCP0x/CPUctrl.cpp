// CPU Control NCP0x -------------------------------------------------------------------
// Sistema de Supervision del Hardware Instalado
#include "NCP0x.h"
#include "CPUctrl.h"

// Inicializacion del Hardware ---------------------------------------------------------
int CPUs_buffer::inicilizar_hardware( char *nodos ) 
{
	int ret,i,n_nodos;
	ret = false;
	i = 0;
	
	if( nodos[0] == 0 ) {
		return( ret );
	}
	
	while( nodos[i] != 0 ) {
		HardwarePLC[i].IDnodo = nodos[i];
		i++;
	}
	HardwarePLC[i].IDnodo = 0;//Final de Lista
	n_nodos = i;

	// Inicializacion del NCP0x Proto + Carga del ExecCmd4All propio de la CPU
	Device->LoadExecCmd(  ALL_NODE , this );	
	error_hardware = false;

	// Pedido del ILIVE x la CPU para iniciar los nodos
	Device->gen_msg(  0 , 0 , ALL_NODE , ALL_WHOLIVES , (char*)i , 0 );// Send WhoLive
	
	timerMarco = millis() + 200 ;// time out de espera para el ILIVE
	cont_marco = 0;
	flag_marco = true;	
	return( ret);
}//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
int CPUs_buffer::checkWhoLives ( void ) 
{
	int ret,i;
	char buffer[10];
	ret = true;
	i = 0;

	// Verifica el IsLive -----------------------------------------------
	while( HardwarePLC[i].IDnodo != 0 ) {
		if( HardwarePLC[i].status.IsLive != ON ) {
			ret = WHOLIVE_FAILURE;
		}
		i++;
	}
	// -----------------------------------------------------------------------

	return( ret );
}//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Comando de Execusion en todos lo nodos por igual -( ESPECIAL CPU )------------------- 
// Caso escepcional en que un Nodo tiene su propio ExecCmd4All que pisa el default.
void CPUs_buffer::ExecCmd4this(  char COMANDO , char *datos )
{
	char buffer[7];
	short i;
	short dato1;
	dato1 = datos[1];
	dato1 = ( dato1 << 8 ) | datos[2];

	switch( COMANDO ) {
		case ALL_ILIVE:// ILIVE --------------------------------------------------------
			Serial.print(" ILIVE ID:");
			Serial.println( datos[0] , HEX );
		case ALL_POLO:// POLO ----------------------------------------------------------
#if NCP0x_DEBUG_LEVEL == 1		
			Serial.print(" POLO : "); 
			Serial.println( datos[0] , HEX );
#endif
			if( datos[0] == Device->ThisDeviceID ) {
				// Error Nodo Repetido
				dato1 = DUPLICATED_ID;
				datos[1] = ( dato1 >> 8 ) & 0x00FF;
				datos[2] = ( dato1 >> 0 ) & 0x00FF;
				Device->gen_msg( 0 , 0 , ALL_NODE , ALL_ERRORST , buffer , 2 );
			} else {
				SetOnMarco( datos[0] );
			}
			break;

		case ALL_ERRORST:// Errores Graves ---------------------------------------------
			switch( dato1 ) {
				case LVI_DETECC:
					flag_LVI = ON;
					break;
				case POLO_FAILURE:
					break;
				case DUPLICATED_ID:
					i = 0;
					while( HardwarePLC[i].IDnodo == 0 ) {
						if( HardwarePLC[i].IDnodo == datos[0] ) {
							HardwarePLC[i].status.Duplicated = ON;
						}
						i++;
					}
					break;
			}				
			error_hardware = *((int*)&datos[1]);
			break;
	}
}
// ---------------------------------------------------------------------------------------------------

// Chequea el estado del Hardware --------------------------------------------------------------------
int CPUs_buffer::checkHardWare ( void ) 
{
	int ret,i;
	char buffer[10];
	ret = true;
	i = 0;

	Device->service();


	// Verifica el Marco POLO -----------------------------------------------
	if( millis() >= timerMarco  ) {
		timerMarco = millis() + 200;
		while( HardwarePLC[i].IDnodo != 0 ) {
			if( HardwarePLC[i].status.IsLive == ON ) {
				if( HardwarePLC[i].status.MarcoPOLO == OFF ) {
					ret = false;
				}
			}
			HardwarePLC[i].status.MarcoPOLO = OFF;
			i++;
		}
		if( ret == false ) {
			cont_marco++;
			if( cont_marco > 1 ) {
				flag_marco = false;
			}
		} else {
			cont_marco = 0;
		}
		Device->gen_msg( 1 , 1 , ALL_NODE , ALL_MARCO , (char*)i , 0 );// Send Marco
#if NCP0x_DEBUG_LEVEL == 1		
		Serial.println(" MARCO  ? "); 
#endif
	}
	// -----------------------------------------------------------------------

	return( flag_marco );
}
// ---------------------------------------------------------------------------------------------------

// Pone la bandera de marcopolo en el nodo correspondiente -------------------------------------------
void CPUs_buffer::SetOnMarco( char IDnodo )
{
	int i;
	i = 0;
	while( HardwarePLC[i].IDnodo != 0 ) {
		if( HardwarePLC[i].IDnodo == IDnodo ) {
			HardwarePLC[i].status.IsLive = ON;
			HardwarePLC[i].status.MarcoPOLO = ON;
		}
		i++;
	}
}
// ---------------------------------------------------------------------------------------------------

// Habilitacion Salidas ------------------------------------------------------------------------------
void CPUs_buffer::set_out_enable( char modo )
{
	if( modo != ON ) { 
		modo = OFF; 
	}
	Device->gen_msg( 0 , 0 , ALL_NODE , ALL_ENABLE , &modo , 1 );
}
// ---------------------------------------------------------------------------------------------------
