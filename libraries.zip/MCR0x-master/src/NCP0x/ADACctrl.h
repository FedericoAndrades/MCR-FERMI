// Rack Control Module 
// Cabezera de las Funciones de control del ADAC I/O
// Original : F.A. 10/10/2021

// Define Comandos para el Grupo RACK -----------------------------------------------------------
#define ADAC_RESET				0x00
#define ADAC_SETUP              0x01
#define ADAC_0x02				0x02
#define ADAC_0x03				0x03
#define ADAC_SETOUT             0x04
#define ADAC_UPDATEIN			0x05
#define ADAC_0x06				0x06
#define ADAC_0x07				0x07
#define ADAC_0x08				0x08
#define ADAC_0x09				0x09
#define ADAC_SET_PID            0x0A
#define ADAC_0x0B				0x0B
#define ADAC_0x0C				0x0C
#define ADAC_0x0D				0x0D
#define ADAC_0x0E				0x0E
#define ADAC_0x0F				0x0F
// ----------------------------------------------------------------------------------------------

typedef struct {
	char IDnodo;
	char OFFSET_ADC;
	char OFFSET_DAC;
	char SETUP_DAC_1;
	char SETUP_DAC_2;
	char SETUP_DAC_3;
	char SETUP_DAC_4;
} defADAC;

struct RCF1081_PID_CTRL {
	union  {
		struct  {
			short gainProp;
			short gainIntl;
			short gainDeri;
			short PIDrange_control;

			short timerpid_reload;
			short enable;
			short timerdelay_reload;
			short minimo;
	
			short maximo;
			short mode_PID;
			short Ditter_Freq;
			short Ditter_Vamp;
	
			short N_filtro_LVDT;
			short N_filtro_setpoint;
			short outmin;
			short outmax;
		} setup;
		short mass[16];	
	}actual;
	union  {
		struct {
			short gainProp;
			short gainIntl;
			short gainDeri;
			short PIDrange_control;

			short timerpid_reload;
			short enable;
			short timerdelay_reload;
			short minimo;
	
			short maximo;
			short mode_PID;
			short Ditter_Freq;
			short Ditter_Vamp;
	
			short N_filtro_LVDT;
			short N_filtro_setpoint;
			short outmin;
			short outmax;
		} setup;
		short mass[16];	
	}reflejo;
} ;

class ADACs_buffer : public GrupoNodo {
	private:
		class NCP0x *Device;
		short *last_dac;
		short actu_set_pid;
		short actu_pid;
		short actu_par_pid;

	public:
		unsigned short *adc_lectura;
		short *dac_valor;
		int N_ADC;
		int N_DAC;
		struct RCF1081_PID_CTRL **PIDstack;

		ADACs_buffer( class NCP0x *link , int slots ):adc_lectura( new unsigned short[slots*4]),dac_valor( new short[slots*4]),last_dac( new short[slots*4]),PIDstack( new struct RCF1081_PID_CTRL *[slots*4])
		{
			int i;
			Device = link;
			N_ADC = slots * 4;
			N_DAC = slots * 4;
			for( i = 0 ; i < N_DAC ; i++ ) {
				PIDstack[i] = NULL;
			}
		}
		~ADACs_buffer()
		{
			delete [] adc_lectura;
			delete [] dac_valor;
			delete [] last_dac;
			N_ADC = 0;
			N_DAC = 0;
		}

		// Inicializacion del ADAC --------------------------------------------------------------------
		void init_adac( defADAC *defineADACs ) ;
		// Mantenimiento del ADAC ---------------------------------------------------------------------
		void service( void ) ;
		// Atencion Comandos NCP0x --------------------------------------------------------------------
		void ExecCmd4this( char COMANDO , char *datos ) ;

		// ---------------------------------------------------------------------------------------------------
		void set_pid_register ( short actu_pid , struct RCF1081_PID_CTRL *link ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_gain_prop ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_gain_intl ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_gain_deri ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_range ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_enable ( short actu_pid , short modo ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_timer ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_delay ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_minimo_in ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_maximo_in ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_pid_mode ( short actu_pid , short modo ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_ditter_freq ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_ditter_vamp ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_filtro_LVDT ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_filtro_setpoint ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_out_minimo ( short actu_pid , short valor ) ;
		// ---------------------------------------------------------------------------------------------------
		void set_out_maximo ( short actu_pid , short valor ) ;
};
