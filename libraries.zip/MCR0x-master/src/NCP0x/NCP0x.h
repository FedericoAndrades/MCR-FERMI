/*
 * NCP0x.h
 *
 * Created: 23/9/2021 08:50:25
 *  Author: Federico Andrades
 */ 

#include <Arduino.h>

#define NCP0x_DEBUG_LEVEL   0

// Definicion de Grupos -------------------------------------------------------------------------
#define ALL_NODE                0x00
#define NODE_1                  0x01
#define CPU_NODE                0x02
#define NODE_3                  0x03
#define RACK_NODE               0x04
#define ADAC_NODE               0x05
#define SERVO_NODE              0x06
#define ENCO_NODE               0x07
#define TEMP_NODE               0x08
#define CPWR_NODE               0x09
#define NODE_A                  0x0A
#define NODE_B                  0x0B
#define NODE_C                  0x0C
#define NODE_D                  0x0D
#define HMI_NODE                0x0E
#define PRN_NODE                0x0F
// ----------------------------------------------------------------------------------------------


// Definicion de Errores Graves -----------------------------------------------------------------
#define LVI_DETECC          -1
#define POLO_FAILURE        -2
#define DUPLICATED_ID       -3
#define WHOLIVE_FAILURE       -4
// ----------------------------------------------------------------------------------------------

// Define Comandos para el Grupo ALL ------------------------------------------------------------
#define ALL_RESET                   0x00
#define ALL_ENABLE                  0x01
#define ALL_WHOLIVES                0x02
#define ALL_ILIVE                   0x03
#define ALL_0x04                    0x04
#define ALL_0x05                    0x05
#define ALL_ERRORST                 0x06
#define ALL_POLO                    0x07
#define ALL_MARCO                   0x08
#define ALL_0x09                    0x09
#define ALL_0x0A                    0x0A
#define ALL_0x0B                    0x0B
#define ALL_0x0C                    0x0C
#define ALL_0x0D                    0x0D
#define ALL_0x0E                    0x0E
#define ALL_WRITE                   0x0F
// ----------------------------------------------------------------------------------------------

// Cabezera de NET CAN FERMI
typedef union {
  struct {
    uint32_t ID:29;            /*!< bit:  0..28  Identifier */
    uint32_t RTR:1;            /*!< bit:  29     Remote Transmission Request */
    uint32_t XTD:1;            /*!< bit:  30     Extended Identifier */
    uint32_t ESI:1;            /*!< bit:  31     Error State Indicator */
  } bit;                       /*!< Structure used for bit access */
  uint32_t reg;                /*!< Type used for register access */
  struct {
    unsigned int IDM_0_3    :4; // bit - 3 2 1 0
    unsigned int COMANDO    :5; // bit - 8 7 6 5 4
    unsigned int GRUPO      :4; // bit - 12 11 10 9
    unsigned int PRIORIDAD  :1; // bit - 13
    unsigned int INMEDIATO  :1; // bit - 14
    unsigned int IDM_15_17  :3; // bit - 15 16 17
    unsigned int ID_NODO    :8; // bit - 25 24 23 22 21 20 19 18
    unsigned int IDM_28_26  :3; // bit - 28 27 26
    unsigned int NOT_USE    :3; // bit:  29 30 31
  }NCP0xl;
}canID;

typedef struct {
  canID IDmsg;
  char param[8];
  char largo;
  char prio_int;
  int time_stamp;
} msgNCP0x;

typedef struct {
  unsigned short mem_adress;
  short mem_value;
} write_mem;

// Clase Basica para Grupo -------------------------------------------------
class GrupoNodo {
  public:
    virtual void ExecCmd4this( char COMANDO , char *datos );
};

// Clase Basica para Red NCP0x ---------------------------------------------
class NCP0x : public GrupoNodo {
  public:
    char ThisDeviceID;  // Identificacion del Dispocitivo
    char CUIP[6];       // Codigo Unico de Indetificacion de Periferico.
    char OutPutOn = false; // Habilitacion de Salidas para Perifericos
    char *memorigen = NULL;
    char memsize = 0;

    void init( char ID );
    void service( void );
    void ExecCmd4this( char COMANDO , char *datos );
    int gen_msg( char inmediato , char prioridad , char grupo , char comando , char *buffer , char buff_len );
    void LoadExecCmd( int grupo , class GrupoNodo *clases );
    void ClearExecCmd( int grupo , class GrupoNodo *clases );

  private: 
    class GrupoNodo *ExecClassService[16];  // Punteros de Servicio de Comandos
    void setfilter( canID  filtro , canID mascara , uint32_t index );
    char Marco = false;
};

#define MaxPollMsg  4

#define ON  true
#define OFF false

