/* Rack Control Module */
#include "NCP0x.h"
#include "RACKctrl.h"

// Inicializacion del Rack --------------------------------------------------------------------
void RACKs_buffer::init_rack( defRACK *defineRacks ) 
{
	char i, buffer[10];
	for( i = 0 ; i < C_SAL ; i++ ) {
		Salidas_Last[i] = 0xFFFF;
		RACK_Salidas[i] = 0;
	}
	Device->LoadExecCmd( RACK_NODE , this  );
	
	while( defineRacks->IDnodo != 0 ) {
		buffer[0] = defineRacks->IDnodo;
		buffer[1] = defineRacks->OFFSET_INPUT; 
		buffer[2] = defineRacks->LONG_INPUT;   
		buffer[3] = defineRacks->OFFSET_OUTPUT;
		buffer[4] = defineRacks->LONG_OUTPUT;  
		Device->gen_msg(  0 , 0 , RACK_NODE , RACK_SETUP , buffer , 5 );// Send Setup del Racks
		defineRacks++;
	}
	Device->gen_msg( 0 , 0 , RACK_NODE , RACK_ALLIN , buffer , 0 );// Pide estado de todas las entradas
}
// --------------------------------------------------------------------------------------------

// Mantenimiento del RACK ---------------------------------------------------------------------
void RACKs_buffer::service( void ) 
{
	char i, buffer[5];

	// Actualizacion de Salidas ---------------------------------------------
	for( i = 0 ; i < C_SAL ; i++ ) {
		if( Salidas_Last[i] != RACK_Salidas[i] ) {
			buffer[0] = i;
			*((short*)(&buffer[1])) = RACK_Salidas[i]; 
			Device->gen_msg( 0 , 0 , RACK_NODE , RACK_SETOUT , buffer , 3 );// Send Actualizacion de Salidas
		}
		Salidas_Last[i] = RACK_Salidas[i];
	}
	// ----------------------------------------------------------------------
}
// --------------------------------------------------------------------------------------------


// Atencion Comandos NCP0x --------------------------------------------------------------------
void RACKs_buffer::ExecCmd4this( char COMANDO , char *datos )
{
	char buffer[7];
	char i;

	switch( COMANDO ) {
		case RACK_UPDATEIN: // Resetea el Rack Correspondiente -----------------------------------
#if NCP0x_DEBUG_LEVEL == 1
			Serial.print("RACK_UPDATEIN:");
			Serial.print(datos[1],HEX); Serial.print("-");
			Serial.print(datos[2],HEX);
			Serial.println(datos[3],HEX);
			Serial.print(" C_ENT ");
			Serial.println( C_ENT );
#endif
			if( datos[1] < C_ENT ){
				RACK_Entradas[datos[1]] = ~*((short*)&datos[2]);
			}
			break;
	}
}
// ---------------------------------------------------------------------------------------------------
