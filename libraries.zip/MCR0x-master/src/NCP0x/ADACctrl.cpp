/* Adac Control Module */
#include "NCP0x.h"
#include "ADACctrl.h"

// Inicializacion del Adac --------------------------------------------------------------------
void ADACs_buffer::init_adac( defADAC *defineADACs ) 
{
	char i, buffer[10];
	for( i = 0 ; i < N_ADC ; i++ ) {
		adc_lectura[i] = 0;
	}
	for( i = 0 ; i < N_DAC ; i++ ) {
		dac_valor[i] = 0;
		last_dac[i] = 0;
	}
	
	Device->LoadExecCmd( ADAC_NODE , this );
	
	while( defineADACs->IDnodo != 0 ) {
		buffer[0] = defineADACs->IDnodo;
		buffer[1] = defineADACs->OFFSET_ADC; 
		buffer[2] = defineADACs->OFFSET_DAC;   
		buffer[3] = defineADACs->SETUP_DAC_1;
		buffer[4] = defineADACs->SETUP_DAC_2;
		buffer[5] = defineADACs->SETUP_DAC_3;
		buffer[6] = defineADACs->SETUP_DAC_4;
		Device->gen_msg( 0 , 0 , ADAC_NODE , ADAC_SETUP , buffer , 7 );// Send Setup del ADACs
		defineADACs++;
	}
	
	actu_set_pid = 0;
	actu_pid = 0;
}
// --------------------------------------------------------------------------------------------

// Mantenimiento del Adac ---------------------------------------------------------------------
void ADACs_buffer::service( void ) 
{
	char i, buffer[5];

	// Actualizacion de Salidas Analogicas -----------------------------------
	for( i = 0 ; i < N_DAC ; i++ ) {
		if( last_dac[i] != dac_valor[i] ) {
			buffer[0] = i;
			buffer[1] = ( dac_valor[i] >> 8 ) & 0xFF; 
			buffer[2] = ( dac_valor[i]      ) & 0xFF; 
			Device->gen_msg( 0 , 0 , ADAC_NODE , ADAC_SETOUT , buffer , 3 );// Send Actualizacion de Salidas
				
		}
		last_dac[i] = dac_valor[i];
	}
	/*
	Serial.print(" ADAC actu_set_pid:");
	Serial.print( actu_set_pid );
	Serial.print(" actu_pid :");
	Serial.print( actu_pid );
	Serial.print(" actu_par_pid :");
	Serial.print( actu_par_pid );
	Serial.println(" ");*/
	switch( actu_set_pid ) {
		case 0:
			actu_pid++;
			if( actu_pid >= N_DAC ) {
				actu_pid = 0;
			}
			if( PIDstack[actu_pid] != NULL ) {
				actu_set_pid = 1;
				actu_par_pid = 0;
			}
			break;
		case 1:
			actu_par_pid++;
			if( actu_par_pid >= 16 ) {
				actu_par_pid = 0;
				actu_set_pid++;
			}
			break;
		case 2:
			if( PIDstack[actu_pid]->reflejo.mass[actu_par_pid] != PIDstack[actu_pid]->actual.mass[actu_par_pid] ) {
				buffer[0] = actu_pid;
				buffer[1] = actu_par_pid;
				buffer[2] = ( PIDstack[actu_pid]->actual.mass[actu_par_pid] >> 8 ) & 0xFF; 
				buffer[3] = ( PIDstack[actu_pid]->actual.mass[actu_par_pid]      ) & 0xFF; 
				if( Device->gen_msg( 0 , 0 , ADAC_NODE , ADAC_SET_PID , buffer , 4 ) ==  true ) {
					PIDstack[actu_pid]->reflejo.mass[actu_par_pid] = PIDstack[actu_pid]->actual.mass[actu_par_pid];
				}
			} else {
				actu_par_pid++;
				if( actu_par_pid >= 16 ) {
					actu_par_pid = 0;
					actu_set_pid++;
				}
			}
			break;
		case 3:
			actu_set_pid = 0;
			break;
	}			
	// -----------------------------------------------------------------------
}
// --------------------------------------------------------------------------------------------

// Atencion Comandos NCP0x --------------------------------------------------------------------
void ADACs_buffer::ExecCmd4this( char COMANDO , char *datos )
{
	char buffer[7];
	char i;

	switch( COMANDO ) {
		case ADAC_UPDATEIN: // Seteo de Entradas Analogicas --------------------------------------
			/*if( datos[1] == 1 ) {
				Serial.print("adc[1]:");
				Serial.print( datos[2] , HEX);
				Serial.print( datos[3] , HEX);
				Serial.println();
			}*/
			if( datos[1] < N_ADC ) {
				adc_lectura[ datos[1] ] = ( (short) datos[2] << 8 ) | datos[3] ;
			}
			break;
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_register ( short actu_pid , struct RCF1081_PID_CTRL *link ) 
{
	int i;
	if( PIDstack[actu_pid] == NULL ) {
		PIDstack[actu_pid] = link;
		PIDstack[actu_pid]->actual.setup.gainProp = 500;          
		PIDstack[actu_pid]->actual.setup.gainIntl = 100;          
		PIDstack[actu_pid]->actual.setup.gainDeri = -50;          
		PIDstack[actu_pid]->actual.setup.PIDrange_control = 200;  
		PIDstack[actu_pid]->actual.setup.timerpid_reload = 75;   
		PIDstack[actu_pid]->actual.setup.timerdelay_reload = 0; 
		PIDstack[actu_pid]->actual.setup.enable = 1;            
		PIDstack[actu_pid]->actual.setup.minimo = 0;            
		PIDstack[actu_pid]->actual.setup.maximo = 1023;       
		PIDstack[actu_pid]->actual.setup.mode_PID = 0;     
		PIDstack[actu_pid]->actual.setup.Ditter_Freq = 1;  
		PIDstack[actu_pid]->actual.setup.Ditter_Vamp = 0;  
		PIDstack[actu_pid]->actual.setup.N_filtro_LVDT = 1;    
		PIDstack[actu_pid]->actual.setup.N_filtro_setpoint = 1;
		PIDstack[actu_pid]->actual.setup.outmin = -1023;           
		PIDstack[actu_pid]->actual.setup.outmax = 1023;           
	}
}
// ---------------------------------------------------------------------------------------------------


// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_gain_prop ( short actu_pid , short valor ) 
{
	if( PIDstack[actu_pid] != NULL ) {
		PIDstack[actu_pid]->actual.setup.gainProp = valor;
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_gain_intl ( short actu_pid , short valor ) 
{
	if( PIDstack[actu_pid] != NULL ) {
		PIDstack[actu_pid]->actual.setup.gainIntl = valor;
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_gain_deri ( short actu_pid , short valor ) 
{
	if( PIDstack[actu_pid] != NULL ) {
		PIDstack[actu_pid]->actual.setup.gainDeri = valor;
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_range ( short actu_pid , short valor ) 
{
	if( PIDstack[actu_pid] != NULL ) {
		PIDstack[actu_pid]->actual.setup.PIDrange_control = valor;
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_enable ( short actu_pid , short modo ) 
{
	modo = modo & 0x01;
	if( PIDstack[actu_pid] != NULL ) {
		PIDstack[actu_pid]->actual.setup.enable = modo;
	}
}
// ---------------------------------------------------------------------------------------------------


// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_timer ( short actu_pid , short valor ) 
{
	if( valor >= 0 ) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.timerpid_reload = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_delay ( short actu_pid , short valor ) 
{
	if( valor >= 0 ) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.timerdelay_reload = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_minimo_in ( short actu_pid , short valor ) 
{
	if(( valor <= 4095 )&&( valor >= 0 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.minimo = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_maximo_in ( short actu_pid , short valor ) 
{
	if(( valor <= 4095 )&&( valor >= 0 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.maximo = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_pid_mode ( short actu_pid , short modo ) 
{
	modo = modo & 0x03;
	if( PIDstack[actu_pid] != NULL ) {
		PIDstack[actu_pid]->actual.setup.mode_PID = modo;
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_ditter_freq ( short actu_pid , short valor ) 
{
	if(( valor <= 200 )&&( valor >= 0 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.Ditter_Freq = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_ditter_vamp ( short actu_pid , short valor ) 
{
	if(( valor <= 250 )&&( valor >= 0 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.Ditter_Vamp = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_filtro_LVDT ( short actu_pid , short valor ) 
{
	if(( valor <= 1000 )&&( valor >= 0 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.N_filtro_LVDT = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_filtro_setpoint ( short actu_pid , short valor ) 
{
	if(( valor <= 1000 )&&( valor >= 0 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.N_filtro_setpoint = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_out_minimo ( short actu_pid , short valor ) 
{
	if(( valor <= 1023 )&&( valor >= -1023 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.outmin = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------
void ADACs_buffer::set_out_maximo ( short actu_pid , short valor ) 
{
	if(( valor <= 1023 )&&( valor >= -1023 )) {
		if( PIDstack[actu_pid] != NULL ) {
			PIDstack[actu_pid]->actual.setup.outmax = valor;
		}
	}
}
// ---------------------------------------------------------------------------------------------------
