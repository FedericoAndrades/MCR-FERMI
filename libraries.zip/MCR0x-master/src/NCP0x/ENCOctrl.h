/* Rack Control Module */
// Cabezera de las Funciones de control del ENCO I/O
// Original : F.A. 11/02/2010

// Define Comandos para el Grupo ENCO -----------------------------------------------------------
#define ENCO_RESET                   0x00
#define ENCO_SETUP                   0x01
#define ENCO_ERROR                   0x02
#define ENCO_0x03                    0x03
#define ENCO_0x04                    0x04
#define ENCO_INC_CONT                0x05
#define ENCO_0x06                    0x06
#define ENCO_0x07                    0x07
#define ENCO_0x08                    0x08
#define ENCO_0x09                    0x09
#define ENCO_RESET_THIS              0x0A
#define ENCO_0x0B                    0x0B
#define ENCO_0x0C                    0x0C
#define ENCO_0x0D                    0x0D
#define ENCO_0x0E                    0x0E
#define ENCO_0x0F                    0x0F
// ----------------------------------------------------------------------------------------------

typedef struct {
	char IDnodo;
	char OFFSET_ENCODER;
	short *Contador_Posicion[4];
	short *Encoder_error[4];
} defENCO;

// Error de Encoder -----------------------------------------------------------------------------
#define ERROR_FASE_CHANGE			-1
#define ERROR_HIGH_SPEED			-2
#define ERROR_ON_INITIALIZATION		-3
// ----------------------------------------------------------------------------------------------

typedef struct {
	short *Contador_Posicion;
	short *Encoder_error;
}Encoder;

class ENCOs_buffer : public GrupoNodo {
	private:
		class NCP0x *Device;
		Encoder *Encoders;
		short N_ENCODERS;

	public:
		ENCOs_buffer( class NCP0x *link , int slots ):Encoders( new Encoder[slots*4])
		{
			Device = link;
			N_ENCODERS = slots * 4;
		}
		~ENCOs_buffer()
		{
			delete [] Encoders;
			N_ENCODERS = 0;
		}

		// Inicializacion del ENCO --------------------------------------------------------------------
		void init_enco( defENCO *defineENCOs ) ;
		// Reset Individual de ENCODERS ---------------------------------------------------------------
		void rst_enco( char id_enco ) ;
		// Atencion Comandos NCP0x --------------------------------------------------------------------
		void ExecCmd4this( char COMANDO , char *datos ) ;
};


