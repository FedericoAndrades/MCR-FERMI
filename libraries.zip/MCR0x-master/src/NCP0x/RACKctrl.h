/* Rack Control Module */

// Define Comandos para el Grupo RACK -----------------------------------------------------------
#define RACK_RESET                   0x00
#define RACK_SETUP                   0x01
#define RACK_0x02                    0x02
#define RACK_0x03                    0x03
#define RACK_SETOUT                  0x04
#define RACK_UPDATEIN                0x05
#define RACK_0x06                    0x06
#define RACK_0x07                    0x07
#define RACK_0x08                    0x08
#define RACK_0x09                    0x09
#define RACK_0x0A                    0x0A
#define RACK_0x0B                    0x0B
#define RACK_0x0C                    0x0C
#define RACK_0x0D                    0x0D
#define RACK_0x0E                    0x0E
#define RACK_ALLIN                   0x0F
// ----------------------------------------------------------------------------------------------

typedef struct {
	char IDnodo;
	char OFFSET_INPUT;
	char LONG_INPUT;
	char OFFSET_OUTPUT;
	char LONG_OUTPUT;
} defRACK;

class RACKs_buffer : public GrupoNodo {
  private:
    class NCP0x *Device;

  public:
    unsigned short* RACK_Salidas;
    unsigned short* RACK_Entradas;
    unsigned short* Salidas_Last;
    int C_SAL = 0;
    int C_ENT = 0;

    RACKs_buffer( class NCP0x *link , int salidas , int entradas ):RACK_Salidas( new unsigned short[salidas] ),RACK_Entradas( new unsigned short[entradas]),Salidas_Last( new unsigned short[salidas] )
    {
      Device = link;
      C_SAL = salidas;
      C_ENT = entradas;
    }
    ~RACKs_buffer()
    {
      delete [] RACK_Salidas;
      delete [] RACK_Entradas;
      delete [] Salidas_Last;
      C_SAL = 0;
      C_ENT = 0;
    }

    // Inicializacion del Rack --------------------------------------------------------------------
    void init_rack( defRACK *defineRacks ) ;

    // Mantenimiento del RACK ---------------------------------------------------------------------
    void service( void ) ;

    // Atencion Comandos NCP0x --------------------------------------------------------------------
    void ExecCmd4this( char COMANDO , char *datos ) ;
};