/*
 * NCP0x.c
 *
 * Created: 23/9/2021 12:31:21
 *  Author: Federico Andrades
 */ 

#include "NCP0x.h"
#include "CAN/CAN.h"

// Inicializacion del NODO NCP0x ---------------------------------------------------------------------
void NCP0x::init ( char ID )
{
  int i;
  canID filtro,mascara;
  
  ThisDeviceID = ID;

  for( i = 0 ; i < 16 ; i++ ) {
    ExecClassService[i] = NULL;
  }
  LoadExecCmd( 0 , this );//Comando de Ejecucion para todos los Nodos NCP0x
  OutPutOn = false;

  // Define el Filtro de CAN y Reinicia la red
  pinMode( PIN_CAN_STANDBY , OUTPUT );

  // start the CAN bus at 333333 kbps
  if (!CAN.begin(333333)) {
    Serial.println("Starting CAN failed!");
    while (1);
  }

  digitalWrite( PIN_CAN_STANDBY  , LOW );
  
  /*--- FILTROS ----*/
  // Filtro Index 0
  filtro.reg = 0;
  mascara.reg = 0;
  filtro.NCP0xl.ID_NODO = CPU_NODE << 4;
  mascara.NCP0xl.ID_NODO = 0xFF;
  filtro.NCP0xl.GRUPO = ALL_NODE;
  mascara.NCP0xl.GRUPO = 0xFF;
  setfilter( filtro , mascara , 0 );

  // Filtro Index 1
  filtro.reg = 0;
  mascara.reg = 0;
  filtro.NCP0xl.GRUPO = RACK_NODE;
  mascara.NCP0xl.GRUPO = 0xFF;
  setfilter( filtro , mascara , 1 );
  
}
// ---------------------------------------------------------------------------------------------------

void NCP0x::setfilter( canID  filtro , canID mascara , uint32_t index )
{

}

void  NCP0x::LoadExecCmd( int grupo , class GrupoNodo *clases ) 
{
  ExecClassService[ grupo ] = clases;
}

void  NCP0x::ClearExecCmd( int grupo , class GrupoNodo *clases )
{
  ExecClassService[ grupo ] = NULL;
}


// Rutina de Antencion a mensajes CAN -----------------------------------------------------------------
void NCP0x::service( void  )
{
  char interrupt;
  msgNCP0x temp;
 
  char i,cont_msg = 0;
  char prn[128];
  int packetSize = CAN.parsePacket();
  
  if( packetSize ) {
    cont_msg++;

    //can_clear_interrupt_status(&can_instance, CAN_RX_FIFO_0_NEW_MESSAGE);
    temp.IDmsg.bit.ID = CAN.packetId();
    temp.largo = packetSize;
    for( int i = 0 ; i < packetSize ; i++ ) {
      temp.param[i] = (char)CAN.read();
    }
#if NCP0x_DEBUG_LEVEL == 2
      sprintf( prn , "\n -RX--------------------------------- ");Serial.print(prn);
      sprintf( prn , "\n ID : %0X " , temp.IDmsg.bit.ID );Serial.print(prn);
      sprintf( prn , "\n ID_NODO : %02X " , temp.IDmsg.NCP0xl.ID_NODO);Serial.print(prn);
      sprintf( prn , "\n ID_GRUPO : %02X  " , temp.IDmsg.NCP0xl.GRUPO);Serial.print(prn);
      sprintf( prn , "\n ID_COMANDO : %02X  " , temp.IDmsg.NCP0xl.COMANDO );Serial.print(prn);
      sprintf( prn , "\n ID_DATA : ");Serial.print(prn);
      for( i = 1 ; i < ( temp.largo - 1 ) ; i++ ) {
        sprintf( prn , "%02X,",temp.param[i]);Serial.print(prn);
      }
      sprintf( prn , "\n ------------------------------------ \n");Serial.print(prn);
#endif    
    if( ExecClassService[ temp.IDmsg.NCP0xl.GRUPO ] != NULL ) {
#if NCP0x_DEBUG_LEVEL >= 2      
      Serial.print(" Exec Grupo ");
      Serial.println( temp.IDmsg.NCP0xl.GRUPO , HEX );
#endif      
      ExecClassService[ temp.IDmsg.NCP0xl.GRUPO ]->ExecCmd4this ( temp.IDmsg.NCP0xl.COMANDO , &temp.param[0] );
    }
  }
}
// ---------------------------------------------------------------------------------------------------

// Generadora de Mensajes NCP0x ----------------------------------------------------------------------
// ( ojo que no comprueba si el mensaje esta bien redactado )
int NCP0x::gen_msg(  char inmediato , char prioridad , char grupo , char comando , char *buffer , char buff_len )
{
  char interrupt;
  msgNCP0x temp;
  int ret = true;
  char i;
  canID id_mensaje;
  char prn[128];
  
#if NCP0x_DEBUG_LEVEL == 2
  sprintf( prn , "\n -TX--------------------------------- ");Serial.print(prn);
#endif
  id_mensaje.reg = 0xFFFFFFFFFFFF;
  id_mensaje.NCP0xl.INMEDIATO = !inmediato;
  id_mensaje.NCP0xl.PRIORIDAD = !prioridad;
  id_mensaje.NCP0xl.GRUPO     = grupo;
  id_mensaje.NCP0xl.COMANDO   = comando;
  id_mensaje.NCP0xl.ID_NODO   = ThisDeviceID; 
#if NCP0x_DEBUG_LEVEL == 2
  sprintf( prn , "\n ID : %0X " , id_mensaje.bit.ID );Serial.print(prn);
  sprintf( prn , "\n ID_NODO : %02X " , id_mensaje.NCP0xl.ID_NODO);Serial.print(prn);
  sprintf( prn , "\n ID_GRUPO : %02X  " , id_mensaje.NCP0xl.GRUPO);Serial.print(prn);
  sprintf( prn , "\n ID_COMANDO : %02X  " , id_mensaje.NCP0xl.COMANDO );Serial.print(prn);
  sprintf( prn , "\n ID_DATA : ");Serial.print(prn);
#endif
  CAN.beginExtendedPacket(id_mensaje.bit.ID);
  CAN.write(ThisDeviceID);
  for( i = 0 ; i < buff_len ; i++ ) {
#if NCP0x_DEBUG_LEVEL == 2
    sprintf( prn , "%02X,",*buffer);Serial.print(prn);
#endif
    CAN.write( *(buffer++) );
  }
#if NCP0x_DEBUG_LEVEL == 2
  sprintf( prn , "\n ------------------------------------ \n");Serial.print(prn);
#endif
  CAN.endPacket();

#if NCP0x_DEBUG_LEVEL == 1
  Serial.println("Send CAN TX ----- ");
#endif  
  return( ret );
}
// ---------------------------------------------------------------------------------------------------

// Comando de Execusion en todos lo nodos por igual --------------------------------------------------
void NCP0x::ExecCmd4this(  char COMANDO , char *datos )
{
  char buffer[7];
  int *ptr;
  write_mem *temp;
  Serial.print("ExecCmd4All ="); Serial.println( COMANDO , HEX );
  
  switch( COMANDO ) {
    case ALL_RESET:// Comando de Reset General -------------------------------------
      OutPutOn = OFF;
      break;

    case ALL_ENABLE:// Enable Output -----------------------------------------------
      if( datos[1] == ON ) {
        OutPutOn = ON;
      } else {
        OutPutOn = OFF;
      }
      break;

    case ALL_WHOLIVES:// Who Lives, pide constestacion ILIVE -----------------------
      buffer[0] = CUIP[0];
      buffer[1] = CUIP[1];
      buffer[2] = CUIP[2];
      buffer[3] = CUIP[3];
      buffer[4] = CUIP[4];
      buffer[5] = CUIP[5];
      gen_msg( 0 , 0 , ALL_NODE , ALL_ILIVE , buffer , 6 );// Send ILIVE
      Marco = ON;
      break;

    case ALL_ILIVE:// ILIVE --------------------------------------------------------
    case ALL_POLO:// POLO ----------------------------------------------------------
      if( datos[0] == ThisDeviceID ) {
        // Error Nodo Repetido
        *((int*)&buffer[2]) = DUPLICATED_ID;
        gen_msg(  0 , 1 , ALL_NODE , ALL_ERRORST , buffer , 2 );
        OutPutOn = OFF;
      }
      break;

    case ALL_ERRORST:// Errores Graves ---------------------------------------------
      switch( *((int*)&datos[1]) ) {
        case LVI_DETECC:
        case POLO_FAILURE:
        case DUPLICATED_ID:
          OutPutOn = OFF;
          break;
      }
      break;

    case ALL_MARCO:// MARCO --------------------------------------------------------
      gen_msg( 0 , 1 , ALL_NODE , ALL_POLO , buffer , 0 );// Send POLO
      Marco = ON;
      break;

    case ALL_WRITE:// Escritura directa de Memoria ---------------------------------
      if( memorigen != 0x0000 ) {
        //temp = (write_mem*)&datos[1];
        //ptr = (short*)memorigen + (short*)temp->mem_adress ;
        //*ptr = temp->mem_value;
      }
      break;
  }
}
// ---------------------------------------------------------------------------------------------------


void GrupoNodo::ExecCmd4this(  char COMANDO , char *datos )
{
  Serial.println(" ExecCmd4this weak ");
}