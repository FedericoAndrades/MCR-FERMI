// CPU Control NCP0x -------------------------------------------------------------------

// Sistema de Supervision del Hardware Instalado

struct InstallNodo {
	char IDnodo;
	struct {
		unsigned int HardERROR      :1;
		unsigned int Duplicated     :1;
		unsigned int bit_2          :1;
		unsigned int bit_3          :1;
		unsigned int bit_4          :1;
		unsigned int bit_5          :1;
		unsigned int bit_6          :1;
		unsigned int bit_7          :1;
		unsigned int bit_8          :1;
		unsigned int bit_9          :1;
		unsigned int bit_A          :1;
		unsigned int bit_B          :1;
		unsigned int bit_C          :1;
		unsigned int bit_D          :1;
		unsigned int IsLive         :1;
		unsigned int MarcoPOLO      :1;
	} status;			
} ;

class CPUs_buffer : public GrupoNodo {
	private:
		class NCP0x *Device;
		int flag_marco;
		int cont_marco;
		unsigned long timerMarco;

		// Pone la bandera de marcopolo en el nodo correspondiente -------------------------------------------
		void SetOnMarco( char IDnodo ) ;

	public:
		struct InstallNodo HardwarePLC[32];
		char OutEnable = false;
		char flag_LVI = false;
		char error_hardware = false;

		CPUs_buffer( class NCP0x *link ) {
			Device = link;
		}

		int inicilizar_hardware(  char *nodos ) ;

		void ExecCmd4this(  char COMANDO , char *datos ) ;

		int checkWhoLives ( void ) ;

		// Chequea el estado del Hardware x marcopolo --------------------------------------------------------
		int checkHardWare ( void ) ;

		// Habilitacion Salidas ------------------------------------------------------------------------------
		void set_out_enable( char modo ) ;
};

