/* Cabezera de SMC101 para MCP0x */
/* Mod para SMC101.N07 o posterior */
#define ERR_PARAMETROS	1

// Define Comandos para el Grupo SERVO -----------------------------------------------------------
#define SMC_RESET_ALL               0x00
#define SMC_RESET                   0x01
#define SMC_STTS                    0x02
#define SMC_ERROR                   0x03
#define SMC_BREAK                   0x04
#define SMC_START                   0x05
#define SMC_0x06                    0x06
#define SMC_SETPOINT                0x07
#define SMC_LOGIC                   0x08
#define SMC_LOW_TORQUE              0x09
#define SMC_CLEAR                   0x0A
#define SMC_INPUT_MODE              0x0B
#define SMC_FREQ                    0x0C
#define SMC_RAMPA                   0x0D
#define SMC_PULS                    0x0E
#define SMC_CFG_CONJ                0x0F
// ----------------------------------------------------------------------------------------------

typedef	union {
	struct {
		unsigned short JMPTO		:4;	// Numero de Conjunto de parametros que debe interpretar al terminar el actual
		unsigned short H_JMP		:1; // Habilitacion de Salto de Conjunto
		unsigned short RSTonEND		:1; // Resetea los contadores al finalizar 
		unsigned short bit_6		:1;
		unsigned short bit_7		:1;
		unsigned short TOC5			:1;	// Habilitacion de Entrada Rapida TOC5
		unsigned short TOC4			:1; // Habilitacion de Entrada Rapida TOC4
		unsigned short TOC3			:1; // Habilitacion de Entrada Rapida TOC3
		unsigned short TOC2			:1; // Habilitacion de Entrada Rapida TOC2
		unsigned short TOC1			:1; // Habilitacion de Entrada Rapida TOC1
		unsigned short CURVA		:1;	// 0: Curva de Aceleracion S | 1: Recta de Aceleracion.
		unsigned short TORQ_LOW		:1; // Avance con Torque Bajo
		unsigned short MODO_AVANC	:1;	// Modo del avance  1:relativo al punto en que esta ;o 0:Absoluto 
	} bit;
	struct {
		char LSB;
		char MSB;
	}byte;
	unsigned short word;
} conf_gen_cfg;

typedef struct {
	union {
		struct {
			unsigned short BUSY			:1;
			unsigned short POWER		:1;
			unsigned short RUN			:1;
			unsigned short STOP			:1;
			unsigned short ORIGEN		:1;
			unsigned short END			:1;
			unsigned short ERROR		:1;
			unsigned short TORQUE		:1;
			unsigned short IN_DETEC		:1;
			unsigned short bit_9		:1;
			unsigned short INPUT_STTS	:6;
		}bit; 
		struct {
			char LSB;
			char MSB;
		}byte;
		unsigned short word;
	}stts;
	int posicion_actual;
	char INPUT_STTS;
} SMC_stts;

typedef struct {
	char IDnodo;
	SMC_stts control;
	struct {
		short IDerror;
	}systema;
} SMC;

#define IN_TOC1	            0
#define IN_TOC2	            1
#define IN_TOC3	            2
#define IN_TOC4	            3
#define IN_TOC5             4
           
#define IN_NONE				0
#define IN_MARCHA			1
#define IN_PARADA			2
#define IN_PARADA_WCLEAR	3
#define IN_HOME				4
#define IN_HOME_WCLEAR 		5
#define IN_TOPE				6
#define IN_TOPE_WCLEAR		7
#define IN_FRENO			8
#define IN_SETPOS           9
               

#define NO_ERROR			0
#define SRV_NOT_READY		1
#define SRV_ON_ERROR		2
#define NO_HOME_DETECT		3
#define NO_TOPE_DETECT		4


class SMCs_buffer : public GrupoNodo {
	private:
		class NCP0x *Device;
		short N_SMC = 0;

	public:
		SMC *ServoMotorControl;
		SMCs_buffer(  class NCP0x *link , short slots ):ServoMotorControl( new SMC[slots+1] )
		{
			Device = link;
			N_SMC = slots+1;
		}
		~SMCs_buffer()
		{
			delete [] ServoMotorControl;
			N_SMC = 0;
		}


		// Inicializacion del ADAC --------------------------------------------------------------------
		void SMCinit( short slot ) ;
		// RESET ----------------------------------------------------------------------------------------------
		void SMCreset ( short slot ) ;
		// BREAK ----------------------------------------------------------------------------------------------
		void SMCbreak ( short slot ) ;
		// START ----------------------------------------------------------------------------------------------
		void SMCstart ( short slot , char IDconj ) ;
		// SetPoint Config ---------------------------------------------------------------------------------------
		void SMCsetpoint ( short slot , int posicion ) ;
		// Logica ---------------------------------------------------------------------------------------------
		void SMClogica ( short slot , char Modo ) ;
		// Torque ---------------------------------------------------------------------------------------------
		void SMCtorque ( short slot , char Modo ) ;
		// Clear ----------------------------------------------------------------------------------------------
		void SMCclear ( short slot ) ;
		// Input Config ---------------------------------------------------------------------------------------
		void SMCinput ( short slot , char Entrada , char Modo , char Flanco , char Hab_ret_lec , int Ret_lec , short delta_modo9 ) ;
		// Frequency Config ---------------------------------------------------------------------------------------
		void SMCfreq ( short slot , char IDconfig , unsigned short Freq_Inicial , unsigned short Freq_Final ) ;
		// Rampa Config ---------------------------------------------------------------------------------------
		void SMCrampa ( short slot , char IDconfig , unsigned short tim_rampa_acel , unsigned short tim_rampa_desacel ) ;
		// Pulsos Config ---------------------------------------------------------------------------------------
		void SMCpuls ( short slot , char IDconfig , int largo ) ;
		// Cfg Config ---------------------------------------------------------------------------------------
		void SMCcfg ( short slot , char IDconfig , conf_gen_cfg config ) ;
		// stop smc -------------------------------------------------------------------------------------------
		short SMCstop( short slot ) ;
		// ready smc -------------------------------------------------------------------------------------------
		short SMCready( short slot ) ;
		// power smc -------------------------------------------------------------------------------------------
		short SMCpower( short slot )	;
		// posicion smc -------------------------------------------------------------------------------------------
		int SMCposic( short slot )	;
		// detec input smc -------------------------------------------------------------------------------------------
		short SMCinputDetec( short slot ) ;
		// detec input stts -------------------------------------------------------------------------------------------
		short SMCsttsINPUT( short slot ) ;

		// Atencion Comandos NCP0x --------------------------------------------------------------------
		void ExecCmd4this( char COMANDO , char *datos ) ;
};




