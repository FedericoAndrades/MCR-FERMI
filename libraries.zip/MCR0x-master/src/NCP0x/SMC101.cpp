/* SMC-101  for MCR0x */
// 28/08/2013 Agregado del estado de la Entradas (INPUT) en status.
// 15/11/2013 Modificacion de configuraciones de entradas.

#include "NCP0x.h"
#include "SMC101.h"


void SMCs_buffer::SMCinit( short slot ) 
{
	if( slot < N_SMC ) {
		ServoMotorControl[slot].IDnodo = ( SERVO_NODE << 4 ) | slot;
		ServoMotorControl[slot].control.posicion_actual = 0;
		ServoMotorControl[slot].control.stts.bit.BUSY	= ON;
		ServoMotorControl[slot].control.stts.bit.POWER	= OFF;
		ServoMotorControl[slot].control.stts.bit.RUN	= OFF;
		ServoMotorControl[slot].control.stts.bit.STOP	= OFF;
		ServoMotorControl[slot].control.stts.bit.ORIGEN	= OFF;
		ServoMotorControl[slot].control.stts.bit.END	= OFF;
		ServoMotorControl[slot].control.stts.bit.ERROR	= OFF;
		ServoMotorControl[slot].control.stts.bit.TORQUE	= OFF;	
		SMCreset( slot );

		Device->LoadExecCmd( SERVO_NODE , this );
	}
}

// Comandos NCP0x --------------------------------------------------------------------
// HHHHLLLL|HHHHLLLL|HHHHLLLL|HHHHLLLL|HHHHLLLL|HHHHLLLL|HHHHLLLL|HHHHLLLL|
// datos[0]|datos[1]|datos[2]|datos[3]|datos[4]|datos[5]|datos[6]|datos[7]|
// ORIGEN  |DESTINO |IDconfig| --- param 2 --- | --- param 3 --- | NU     |
// ORIGEN  |DESTINO |IDconfig| ------------- param 4 ----------- | NU     |
//         |        |        |        |        |        |        |        |

// RESET ----------------------------------------------------------------------------------------------
void SMCs_buffer::SMCreset ( short slot )
{
	/* ------------------------------------------------------------------------------------------
	Comando Reset del Modulo ( Este comando es generado por la CPU )
		Este comando no tiene parametros e interrumpe cualquier comando que se este ejecutando poniendo 
			el servo pack en desabilitado, como si nunca se hubira iniciado su uso.
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	if( slot >= N_SMC ) {
		cmd = SMC_RESET_ALL;
	} else {
		cmd = SMC_RESET;
		ServoMotorControl[slot].control.stts.bit.BUSY = ON;
	}
	buffer[0] = ServoMotorControl[slot].IDnodo;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 1 );
}	
// ----------------------------------------------------------------------------------------------------
	
// BREAK ----------------------------------------------------------------------------------------------
void SMCs_buffer::SMCbreak ( short slot )
{
	/* ------------------------------------------------------------------------------------------
	Comando Parada ( Este comando es generado por la CPU )
		Este comando no tiene parametros y obliga a detener el servo donde esta sin perder referencia
			y devuelve como status un stop forzado y la referecia de donde quedo.
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	cmd = SMC_BREAK;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	ServoMotorControl[slot].control.stts.bit.BUSY = ON;
	ServoMotorControl[slot].control.stts.bit.RUN = OFF;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 1 );
}	
// ----------------------------------------------------------------------------------------------------

// START ----------------------------------------------------------------------------------------------
void SMCs_buffer::SMCstart ( short slot , char IDconj )
{
	/* ------------------------------------------------------------------------------------------
	Comando START ( Este comando es generado por la CPU )
		parametro 1	: B:xxxxCCCC 
						CCCC   	= Determina el numero de conjunto de paramteros c/arranca.
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	cmd = SMC_START;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	buffer[1] = IDconj & 0x0F;
	ServoMotorControl[slot].control.stts.bit.BUSY = ON;
	ServoMotorControl[slot].control.stts.bit.STOP = OFF;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 2 );
}	
// ----------------------------------------------------------------------------------------------------

// SetPoint Config ---------------------------------------------------------------------------------------
void SMCs_buffer::SMCsetpoint ( short slot , int posicion )
{
	char cmd,buffer[8];
	cmd = SMC_SETPOINT;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	/* ------------------------------------------------------------------------------------------
	Comando PULS ( Este comando es generado por la CPU )
		parametro 1	: B:xxxxxxxx 
		parametro 2 y parametro 3 : En conjunto forman el valor de avance
	-------------------------------------------------------------------------------------------*/
	buffer[1] = 0 ;
	buffer[2] = ( posicion >> 24 ) & 0x000000FF;
	buffer[3] = ( posicion >> 16 ) & 0x000000FF;
	buffer[4] = ( posicion >>  8 ) & 0x000000FF;
	buffer[5] = ( posicion >>  0 ) & 0x000000FF;
	//ServoMotorControl[slot].stts.BUSY = ON;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 6 );
}	
// ----------------------------------------------------------------------------------------------------

// Logica ---------------------------------------------------------------------------------------------
void SMCs_buffer::SMClogica ( short slot , char Modo )
{
	/* ------------------------------------------------------------------------------------------
	Comando LOGIC ( Este comando es generado por la CPU )
		parametro 1
			0		Deshabilita el controlador y el SERVO PACK
			1		Habilita el controlador y el SERVO PACK
			2		Habilita el controlador y el SERVO PACK y no detectar error de READY
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	cmd = SMC_LOGIC;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	buffer[1] = Modo & 0x03;
	ServoMotorControl[slot].control.stts.bit.BUSY = ON;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 2 );
}	
// ----------------------------------------------------------------------------------------------------

// Torque ---------------------------------------------------------------------------------------------
void SMCs_buffer::SMCtorque ( short slot , char Modo )
{
	/* ------------------------------------------------------------------------------------------
	Comando LOW_TORQUE ( Este comando es generado por la CPU )
		parametro 1
			0		Desactiva la salida de Torque Bajo
			1		Activa las salida de Torque Bajo
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	cmd = SMC_LOW_TORQUE;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	buffer[1] = Modo & 0x01;
	//ServoMotorControl[slot].stts.BUSY = ON;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 2 );
}	
// ----------------------------------------------------------------------------------------------------

// Clear ----------------------------------------------------------------------------------------------
void SMCs_buffer::SMCclear ( short slot )
{
	/* ------------------------------------------------------------------------------------------
	Comando CLEAR ( Este comando es generado por la CPU )
		No tiene parametros. Al generarse un comando de CLEAR la salida CLEAR_SERVO se activa por
			una decima de segundo y se desactiva automaticamente.
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	cmd = SMC_CLEAR;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	ServoMotorControl[slot].control.stts.bit.BUSY = ON;
	Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 1 );
}	
// ----------------------------------------------------------------------------------------------------

// Input Config ---------------------------------------------------------------------------------------
void SMCs_buffer::SMCinput ( short slot , char Entrada , char Modo , char Flanco , char Hab_ret_lec , int Ret_lec , short delta_modo9 ) 
{
	/* ------------------------------------------------------------------------------------------
	Comando MODO DE ENTRADA ( Este comando es generado por la CPU )
		parametro 1	: B:EEEMMMMF 
						EEE = Define el Numero de entrada.
						MMMM = Modo de accion de la entrada.
						F = Determina el Flanco de deteccion (0:Bajada 1:Subida).
		parametro 2 : B:HDDDRRRRRRRRRRRR
						H = Habilita Retardo de lectura
						DDD = Delta de lectura modo 9
						RRRRRRRRRRRR = Parte superior del retardo Lectura
		parametro 3 : B:RRRRRRRRRRRRRRRR
						RRRRRRRRRRRRRRRR = Parte inferior de retardo lectura
	-------------------------------------------------------------------------------------------*/
	char cmd,buffer[8];
	cmd = SMC_INPUT_MODE;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	
	if(( Entrada <= 4 )&&( Entrada >= 0 )) {
		Modo = Modo & 0x0F;
		Flanco = Flanco & 0x01;
		Hab_ret_lec = Hab_ret_lec & 0x01;
		delta_modo9 = delta_modo9 & 0x07;
		if( Ret_lec <= 0 ) {
			Ret_lec = 1;
			Hab_ret_lec = 0;
		}
		Ret_lec = 0x0FFFFFFF; // Limitado a 28bits
		buffer[1] = ( Entrada << 5 ) | ( Modo << 1 ) | Flanco ;
		buffer[2] = (( Ret_lec >> 24 ) & 0x000000FF) | ( Hab_ret_lec << 7 ) | ( delta_modo9 << 4 );
		buffer[3] = (( Ret_lec >> 16 ) & 0x000000FF);
		buffer[4] = (( Ret_lec >>  8 ) & 0x000000FF);
		buffer[4] = (( Ret_lec >>  0 ) & 0x000000FF);
		//ServoMotorControl[slot].stts.BUSY = ON;
		Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 6 );
	}	
}	

// Frequency Config ---------------------------------------------------------------------------------------
void SMCs_buffer::SMCfreq ( short slot , char IDconfig , unsigned short Freq_Inicial , unsigned short Freq_Final )
{
	char cmd,buffer[8];
	cmd = SMC_FREQ;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	/* ------------------------------------------------------------------------------------------
	Comando FREQ ( Este comando es generado por la CPU )
		parametro 1	: B:xxxCCCCC 
						CCCCC = Determina el numero de conjunto de paramteros.
		parametro 2	: Frecuencia Inicial
		parametro 3 : Frecuencia Final
	-------------------------------------------------------------------------------------------*/
	IDconfig = IDconfig & 0x0F;
	
	if( IDconfig < 16 ){
		buffer[1] = IDconfig ;
		buffer[2] = (( Freq_Inicial >>  8 ) & 0x00FF);
		buffer[3] = (( Freq_Inicial >>  0 ) & 0x00FF);
		buffer[4] = (( Freq_Final   >>  8 ) & 0x00FF);
		buffer[5] = (( Freq_Final   >>  0 ) & 0x00FF);
		//ServoMotorControl[slot].stts.BUSY = ON;
		Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 6 );
	}	
}	

// Rampa Config ---------------------------------------------------------------------------------------
void SMCs_buffer::SMCrampa ( short slot , char IDconfig , unsigned short tim_rampa_acel , unsigned short tim_rampa_desacel )
{
	char cmd,buffer[8];
	cmd = SMC_RAMPA;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	/* ------------------------------------------------------------------------------------------
	Comando RAMPA ( Este comando es generado por la CPU )
		parametro 1	: B:xxxxCCCC 
						CCCC = Determina el numero de conjunto de paramteros.
		parametro 2	: Tiempo de Aceleracion (cent.seg.)
		parametro 3 : Tiempo de Desaceleracion (cent.seg.)
	-------------------------------------------------------------------------------------------*/

	IDconfig = IDconfig & 0x0F;
	
	if( IDconfig < 16 ){
		buffer[1] = IDconfig ;
		buffer[2] = (( tim_rampa_acel    >>  8 ) & 0x00FF);
		buffer[3] = (( tim_rampa_acel    >>  0 ) & 0x00FF);
		buffer[4] = (( tim_rampa_desacel >>  8 ) & 0x00FF);
		buffer[5] = (( tim_rampa_desacel >>  0 ) & 0x00FF);
		//ServoMotorControl[slot].stts.BUSY = ON;
		Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 6 );
	}	
}	

// Pulsos Config ---------------------------------------------------------------------------------------
void SMCs_buffer::SMCpuls ( short slot , char IDconfig , int largo )
{
	char cmd,buffer[8];
	cmd = SMC_PULS;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	/* ------------------------------------------------------------------------------------------
	Comando PULS ( Este comando es generado por la CPU )
		parametro 1	: B:xxxxCCCC 
						CCCC  	= Determina el numero de conjunto de paramteros.
		parametro 2 y parametro 3 : En conjunto forman el valor de avance
	-------------------------------------------------------------------------------------------*/
	IDconfig = IDconfig & 0x0F;
	
	if( IDconfig < 16 ){
		buffer[1] = IDconfig ;
		buffer[2] = (( largo >> 24 ) & 0x000000FF);
		buffer[3] = (( largo >> 16 ) & 0x000000FF);
		buffer[4] = (( largo >>  8 ) & 0x000000FF);
		buffer[5] = (( largo >>  0 ) & 0x000000FF);
		//ServoMotorControl[slot].stts.BUSY = ON;
		Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 6 );
	}	
}	

// Cfg Config ---------------------------------------------------------------------------------------
void SMCs_buffer::SMCcfg ( short slot , char IDconfig , conf_gen_cfg config )
{
	char cmd,buffer[8];
	cmd = SMC_CFG_CONJ;
	buffer[0] = ServoMotorControl[slot].IDnodo;
	/* ------------------------------------------------------------------------------------------
	Comando Configuracion del CONJUNTO DE PARAMETROS ( Este comando es generado por la CPU )
		parametro 1	: B:xxxxCCCC 
						CCCC   	= Determina el numero de conjunto de paramteros.
		parametro 2 : B:MTxxabcdeRJCCCC
						M 		= Modo de referencia 0:Relativo 1:Absoluto
						T 		= Define si el avance se realizara con Torque bajo o no (0:No 1:Si)
						a		= Habilita la entrada TOC1
						b		= Habilita la entrada TOC2
						c		= Habilita la entrada TOC3
						d		= Habilita la entrada TOC4
						e		= Habilita la entrada TOC5
						R		= Reset contadores al finalizar. ( pone en cero los contadores al finalizar el conjunto)
						J		= Define si el conjunto debe llamar a otro al finalizar.
						CCCC  	= Determina el numero de conjunto de paramteros que continua.
	-------------------------------------------------------------------------------------------*/
	IDconfig = IDconfig & 0x0F;
	
	if( IDconfig < 16 ){
		buffer[1] = IDconfig ;
		buffer[2] = config.byte.MSB;
		buffer[3] = config.byte.LSB;
		//ServoMotorControl[slot].stts.BUSY = ON;
		Device->gen_msg( 0 , 0 , SERVO_NODE , cmd , buffer , 4 );
	}	
}	


void SMCs_buffer::ExecCmd4this( char COMANDO , char *datos )
{
	char IDconfig,param1,source,flanco,modo,h_ret;
	char Nodo;
	char prn[128];
	unsigned short param2;
	unsigned short param3;
	int param4;
	SMC *periferico;
	short slot;

	Nodo = datos[0];
	slot = Nodo & 0x0F;

	if( slot > N_SMC ) {
		return;
	}
	IDconfig = datos[2] & 0x0F;
	param1 = datos[2];
	param2 = *((short*)&datos[4]);
	param3 = *((short*)&datos[6]);
	param4 = *((int*)&datos[4]);
	
	periferico = &ServoMotorControl[ slot ];
		
	switch( COMANDO ) {
		case SMC_STTS:
			/* ------------------------------------------------------------------------------------------
			Comando STATUS ( Este comando es generado por el Modudo SMC101 )
				parametro 1	 			  : Estados generales
				parametro 2 y parametro 3 : Informan en conjunto el valor del contador absoluto del 
			-------------------------------------------------------------------------------------------*/

			periferico->control.stts.byte.MSB = datos[1];
			periferico->control.stts.byte.LSB = datos[2];
			periferico->control.posicion_actual = datos[3];
			periferico->control.posicion_actual = (periferico->control.posicion_actual << 8) | datos[4];
			periferico->control.posicion_actual = (periferico->control.posicion_actual << 8) | datos[5];
			periferico->control.posicion_actual = (periferico->control.posicion_actual << 8) | datos[6];
			if( periferico->control.stts.bit.ORIGEN == ON ) {
				periferico->control.posicion_actual = 0;
			}

			//periferico->control.stts.bit.INPUT_STTS = datos[7];
			periferico->control.INPUT_STTS = datos[7];
			break;
		
		case SMC_ERROR:
			/* ------------------------------------------------------------------------------------------
			Comando ERROR ( Este comando es generado por el Modudo SMC101 )
				parametro 1	 Estados generales
		
				parametro 2 	Numero identificador de error.
			-------------------------------------------------------------------------------------------*/
			periferico->control.stts.byte.MSB = datos[1];
			periferico->control.stts.byte.LSB = datos[2];
			periferico->systema.IDerror = datos[3];
			periferico->systema.IDerror = (periferico->systema.IDerror << 8) | datos[4];
			break;
	}
}

// stop smc -------------------------------------------------------------------------------------------
short SMCs_buffer::SMCstop( short slot )
{
	if( slot > N_SMC ) {
		return( false );
	}
	if(( ServoMotorControl[slot].control.stts.bit.BUSY == 0 )&&( ServoMotorControl[slot].control.stts.bit.STOP == 1 )) {
		return( true );
	} else {
		return( false );
	}
}
 	
// ready smc -------------------------------------------------------------------------------------------
short SMCs_buffer::SMCready( short slot )
{
	if( slot > N_SMC ) {
		return( false );
	}

	if( !( ServoMotorControl[slot].control.stts.bit.ERROR == 0 ) ) {
		return( true );
	} else {
		return( false );
	}
}
// power smc -------------------------------------------------------------------------------------------
short SMCs_buffer::SMCpower( short slot )
{
	if( slot > N_SMC ) {
		return( false );
	}

	if(( ServoMotorControl[slot].control.stts.bit.BUSY == 0 )&&( ServoMotorControl[slot].control.stts.bit.POWER == 1 )) {
		return( true );
	} else {
		return( false );
	}
}
	
// posicion smc -------------------------------------------------------------------------------------------
int SMCs_buffer::SMCposic( short slot )	
{
	if( slot > N_SMC ) {
		return( 0 );
	}
	return(ServoMotorControl[slot].control.posicion_actual );
}

// detec input smc -------------------------------------------------------------------------------------------
short SMCs_buffer::SMCinputDetec( short slot )
{
	if( slot > N_SMC ) {
		return( 0 );
	}

	if(( ServoMotorControl[slot].control.stts.bit.IN_DETEC == 1 )&&( ServoMotorControl[slot].control.stts.bit.STOP == 1 )) {
		return( true );
	} else {
		return( false );
	}
}
	

// detec input stts -------------------------------------------------------------------------------------------
short SMCs_buffer::SMCsttsINPUT( short slot )
{
	if( slot > N_SMC ) {
		return( 0 );
	}
	return( ServoMotorControl[slot].control.INPUT_STTS );
}

