#include "Mewtocol.h"

#define PRN_CMD_IN		0
#define PRN_CMD_RPLY	0

/*-----------------------------------------------------------------------*/
/* Abre un Canal Esclavo con protocolo MEWTOOCOL						 */
/* 01/08/2005 -- Corrige la respuesta a READ word unit					 */
/*-----------------------------------------------------------------------*/

Newtocol::Newtocol( )
{
    cont_reeinit = 0;
}


short Newtocol::open_slave_nais( struct Mewtocol_setup *link ) {
    short aux;
    link->parcer.estado_rtu = MEWTOCOL_COMM_CLOSE;

	if( link->rtu == 0 ) {
		return( 1 );
	}

	aux = 0;
	if( link->mdt.origen != NULL ) {
		aux++;
	}
	if( link->mld.origen != NULL ) {
		aux++;
	}
	if( link->mr.origen != NULL ) {
		aux++;
	}
	if( link->mx.origen != NULL ) {
		aux++;
	}
	if( link->my.origen != NULL ) {
		aux++;
	}
	if( link->mt.origen != NULL ) {
		aux++;
	}
	if( link->mc.origen != NULL ) {
		aux++;
	}
	if( link->ms.origen != NULL ) {
		aux++;
	}
	if( link->mk.origen != NULL ) {
		aux++;
	}

	if( aux == 0 ) {
		return( 2 );	// No se definieron punteros de variables
	}

    link->Comm->begin( 115200 , SERIAL_8N1 );
	if( ! link->Comm ) {
		return( 3 );	// No se pudo abrir el comm de comunicaciones.
	}

	/* defaults de ID de PLC */
    link->plc.id			= 4;
    link->plc.version    	= 29; 
    link->plc.prog_size   	= 03;
    link->plc.op_mode     	= 0x81;
    link->plc.error_flag  	= 0;
    link->plc.error_code  	= 0;
    link->parcer.estado_rtu = MEWTOCOL_ESPERA_DATOS;
	link->parcer.rx_buffer[0] = '\0';
	link->parcer.tx_buffer[0] = '\0';
	link->parcer.irx =link->parcer.rx_buffer;
	link->parcer.itx =link->parcer.tx_buffer;
	link->parcer.rpt_time = 0;
	cont_reeinit = 0;
	return( 0 );
}


/*-----------------------------------------------------------------------*/
/* Cierra un Canal Esclavo con protocolo MEWTOOCOL						 */
/*-----------------------------------------------------------------------*/
short Newtocol::close_slave_nais( struct Mewtocol_setup *link ) {
	if( link->parcer.estado_rtu != MEWTOCOL_COMM_CLOSE ) {
		link->Comm->end();
	}
    link->parcer.estado_rtu = MEWTOCOL_COMM_CLOSE;
	return( 0 );
}


/*-----------------------------------------------------------------------*/
/* Parser de Mantenimiento de Slave Mewtoocol NAIS                    	 */
/* aqui llamar dentro de un lazo 										 */
/*-----------------------------------------------------------------------*/
short Newtocol::slave_nais( struct Mewtocol_setup *link ) {
    char c;
    short ret;
    unsigned short aux;
 
    switch( link->parcer.estado_rtu ) {
		case MEWTOCOL_COMM_CLOSE:
			/* Link Cerrado */
			break;
			
        case MEWTOCOL_ESPERA_DATOS :
			if( link->Comm->available() ) {
	            c = (link->Comm->read()) & 0x7f;                		/* tomo dato ascii 7 bits */
#ifdef MewtocolDebug
                Serial.write( c );
#endif
    	        if ( c == '%' ) {
        	        link->parcer.irx = link->parcer.rx_buffer;
            	    *(link->parcer.irx++) = c;     /* pongo en buffer primner char */
                	*(link->parcer.irx)   = '\0';	/* pongo '\0'para que quede al final */
	                ret = link->parcer.estado_rtu = MEWTOCOL_RX_DATOS;
    	        } else {
        	        ret=false;
            	}
			} else {
                /* no hay nada salir rapido */
                ret = false;   
            }
            break;
			
        case MEWTOCOL_RX_DATOS :
  			ret = false;   											/* no hay nada salir rapido */
  	    	while( link->Comm->available() ) {
	            c = (link->Comm->read()) & 0x7f;     
#ifdef MewtocolDebug
                Serial.write( c );
#endif
    	        if ( c == '%' ) {
        	        link->parcer.irx = link->parcer.rx_buffer;
            	    *(link->parcer.irx++) = c;     /* pongo en buffer primner char */
                	*(link->parcer.irx)   = '\0';	/* pongo '\0'para que quede al final */
                	cont_reeinit++;
                } else if( link->parcer.irx < &link->parcer.rx_buffer[MAX_CHAR] ) {              		/* si no me pase del largo del buffer */
            	    *(link->parcer.irx++) = c;     /* pongo en buffer primner char */
                	*(link->parcer.irx)   = '\0';	/* pongo '\0'para que quede al final */
                	if( c == CR ) {
#ifdef MewtocolDebug
                        Serial.println(" ");
#endif
                    	ret = analizar_comando( link );
	                    if( ret == true ) { /* aqui hay dos tipos de errores algunos deben responderse */
    	                    link->parcer.estado_rtu = MEWTOCOL_RESPUESTA_LISTA;
    	                    break;
        	            } else {
            	            link->parcer.estado_rtu = MEWTOCOL_ESPERA_DATOS;
            	            break;
                	    }
	                }
				} else {
                	ret = link->parcer.estado_rtu = MEWTOCOL_ESPERA_DATOS;   	/* @ aqui devolver error ? */
                	break;
	            }
			}        	
            break;
			
        case MEWTOCOL_RESPUESTA_LISTA :
			link->parcer.timer = link->parcer.rpt_time;                    /* recargar timer */
            ret = link->parcer.estado_rtu = MEWTOCOL_ESPERA_TIEMPO_RESPUESTA;
            break;
			
        case MEWTOCOL_ESPERA_TIEMPO_RESPUESTA :
            if( link->parcer.timer == 0 ) {
                armar_tx( link , link->parcer.tx_buffer);
                ret = link->parcer.estado_rtu = MEWTOCOL_ESPERA_DATOS;
            }
            break;
        default :
            link->parcer.estado_rtu = MEWTOCOL_COMM_CLOSE;
			ret = false;
            break;
    }
    return ret;
}

/*-----------------------------------------------------------------------*/
/* Actualiza el timer del Slave Mewtoocol NAIS	                    	 */
/* aqui llamar dentro de un lazo de Timers en 0.01 o menos de segundo	 */
/*-----------------------------------------------------------------------*/

void Newtocol::poll_timer_sl_nais( struct Mewtocol_setup *link ) {
	if( link->parcer.timer ) link->parcer.timer--;
}


/*-----------------------------------------------------------------------*/
/* Analiza y responde a un comando				                    	 */
/*-----------------------------------------------------------------------*/
short Newtocol::analizar_comando( struct Mewtocol_setup *link ) {
    short ret,i;
    short last;
    short ok;
	unsigned short address, chk, lrc;
	
    ret = MEWTOCOL_DESCONOCIDO;
#if PRN_CMD_IN
	setLCD(LINE1);printf("%s|",link->parcer.rx_buffer);
#endif
	link->parcer.irx = link->parcer.rx_buffer ;

    for ( i=0 ; (i<MAX_CHAR) && (*link->parcer.irx!='\0') ; i++, link->parcer.irx++ ) ;

    if( i >= MAX_CHAR ) {
        return MEWTOCOL_MENSAJE_RECHAZADO;
    }

    link->parcer.irx--;

    if( *link->parcer.irx != CR ) {
        return MEWTOCOL_MENSAJE_RECHAZADO;
    }

    link->parcer.irx -= 2;                             /* busco chk */

    last = i-3;
    ok = false;                         /* si chk es dos asteriscos doy como valida el chk */
	
    if( (*link->parcer.irx++=='*') && (*link->parcer.irx=='*') ) {
        ok = true;
    } else {
		link->parcer.irx--;
		chk = get_hex(&link->parcer.irx,2);
		link->parcer.irx = link->parcer.rx_buffer; 
		lrc = 0;
        for ( i=0 ; ( i < last ) ; i++, link->parcer.irx++) {
			lrc = lrc ^ *link->parcer.irx;
        }
        if( chk == lrc ) {
            ok = true;
        }
    }
	
    if( ok == false ) {
        armar_respuesta_error( link , MEWTOCOL_BCC_ERROR );
        return true;
	}
	link->parcer.irx = link->parcer.rx_buffer+1;
	
	
    address = get_hex( &link->parcer.irx , 2 );

    if( address != (char) 0xff ) {      /* 0xFF adrress global  no responde ?? */
        if( address != (char)link->rtu ) {    /* si es la direccion de RTU sigo */
            return MEWTOCOL_BAD_STATION;
        }
	}
    if( *link->parcer.irx++ != MEWTOCOL_COMMAND ) {     /* ver si es commando '#' */
        return MEWTOCOL_MENSAJE_RECHAZADO;
    }

/* analizar si read o write */
    switch(*link->parcer.irx++) {
        case 'R' :
            /* analizar el area de memoria ( C area de bits, D datos, S de set timers
            K de valor actual de timers, despues ver que tipo */
            switch(*link->parcer.irx++) {
                case 'C':
                    switch(*link->parcer.irx++) {
                        case 'S':
	                        ret = armar_respuesta_read_one_bit( link );
	                        break;
                        case 'P':
                            ret = armar_respuesta_read_many_bits(link );
                            break;
                        case 'C':
                            ret = armar_respuesta_read_word( link );
                            break;
                        default:
                            armar_respuesta_error( link , MEWTOCOL_NOT_SUPPORT_ERROR); 
							ret=true;
                            break;
					}
                    break;
                case 'K':
                case 'S':
					link->parcer.irx--;
                    ret = armar_respuesta_read_word( link );
                    break;
                case 'D':
					ret = armar_respuesta_read_word( link );
                    break;
                case 'T': /* simular algun PLC */
                    armar_respuesta_plc( link ); ret=true;
                    break;
                default:
                    armar_respuesta_error( link , MEWTOCOL_NOT_SUPPORT_ERROR ); 
					ret=true;
                    break;
            }
            break;
        case 'W' :
            /* analizar el area de memoria ( C area de bits, D datos, S de set timers
            K de valor actual de timers, despues ver que tipo */
            switch(*link->parcer.irx++) {
                case 'C':
                    switch(*link->parcer.irx++) {
                        case 'S':
                            ret = srw_one_bit( link );
                            break;
                        case 'P':
                            ret = srw_many_bit( link );
                            break;
                        case 'C':
                            switch(*link->parcer.irx++) {
                                case 'Y': /* aqui %01#WCCY0000 0002.. */
                                case 'R': /* aqui %01#WCCR0000 0002.. */
									link->parcer.irx--;
                                    ret = set_y_respuesta_write_word( link );
                                    break;
                                default:
                                    armar_respuesta_error( link ,MEWTOCOL_NOT_SUPPORT_ERROR); 
									ret=true;
                                    break;
                                }
                            break;
                        default:
                            armar_respuesta_error( link ,MEWTOCOL_NOT_SUPPORT_ERROR); 
							ret=true;
                            break;
					}
                    break;
                case 'D':
                    switch(*link->parcer.irx++) {
                    	case 'D': /* aqui %01#WDD00000 00002.. */
                        case 'L': /* aqui %01#WDL00000 00002.. */
							link->parcer.irx--;					
                            ret = set_y_respuesta_write_word( link );
                            break;
                        default:
                            armar_respuesta_error( link , MEWTOCOL_NOT_SUPPORT_ERROR); 
							ret=true;
                            break;
					}
                    break;
                case 'S':
                case 'K':
					/* aqui %01#WS0000 0002.. */
					link->parcer.irx--;					
                    ret = set_y_respuesta_write_word( link );
					break;
                default:
                    armar_respuesta_error( link , MEWTOCOL_NOT_SUPPORT_ERROR); 
					ret=true;
                    break;
            }
            break;
        default:
            armar_respuesta_error(link , MEWTOCOL_NOT_SUPPORT_ERROR); 
			ret=true;
            break;
    }
#if PRN_CMD_RPLY
	if( ret == true ) {
		setLCD(LINE3);printf("%s|",link->parcer.tx_buffer);
	}
#endif
    return ret;
}

char Newtocol::ver_area( struct Mewtocol_setup *link , struct mem_info **mem ) {
	char tipo;
	tipo = *link->parcer.irx++;	
    switch(tipo) {
        case 'R': *mem=&link->mr;		break;	// Reles
   	    case 'X': *mem=&link->mx;		break;	// Entradas
       	case 'Y': *mem=&link->my;		break;	// Salidas
        case 'T': *mem=&link->mt;		break;	// Bit Timers
   	    case 'C': *mem=&link->mc;		break;	// Bit Contadores
       	case 'D': 
       		*mem=&link->mdt;		
       		break;	// Datos
       	case 'L': 
       		*mem=&link->mld;		
       		break;	// LD
        case 'S': *mem=&link->ms;		break;	// Estado TC
   	    case 'K': *mem=&link->mk;		break;	// Preset TC
       	default:
           	tipo=false;
		break;
	}
	return tipo;
}

short Newtocol::armar_respuesta_read_many_bits( struct Mewtocol_setup *link ) {
    char ss[MAX_CHAR];
    char bb[30];
    char bval[5];
    short i, direcc_word,direcc_bit,numero;
	unsigned short lrc;
    char tipo;
	struct mem_info *mem;

    strcpy(bb,"");
    numero = get_hex(&link->parcer.irx,1); /* numero de bits 1..8 y avanzo pointer */
	
    if( numero < 0 || numero > 8) return false;

    for(i=0; i<numero; i++) {
        tipo = ver_area( link , &mem );
		if( tipo != false ) {
	        /* aqui diferenciar de que area leer */
    	    direcc_word = get_dec(&link->parcer.irx,3); /* primeros 3 digitos y avanzo pointer */
        	direcc_bit = get_hex(&link->parcer.irx ,1);
	        /* ahora datos bits */
            sprintf( bval , "%d" , (rbit(mem,direcc_word,direcc_bit) != 0 ) );
		} else {
			sprintf( bval , "0" );
		}
	    strcat(bb,bval);
	}

    strcpy(ss,"%");
    sprintf(&ss[1],"%02X$RC", link->rtu);
    strcat(ss,bb);

    lrc=ss[0];
    /* calculo de lrc */
    for (i=1; (i<MAX_CHAR) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);
    return true;
}

short Newtocol::armar_respuesta_read_one_bit( struct Mewtocol_setup *link ) {
    char ss[MAX_CHAR];
    char ss1[30];
    short i, direc_word,direc_bit;
	unsigned short lrc;
    char tipo;
    char valor;
	struct mem_info *mem;
	
    tipo = ver_area( link , &mem );
	
    direc_word = get_dec(&link->parcer.irx,3); /* primeros 4 digitos y avanzo pointer */
    direc_bit  = get_hex(&link->parcer.irx,1);

    /* aqui diferenciar de que area leer */
    /* ahora datos bits */
    valor = (rbit(mem,direc_word,direc_bit))?1:0;

    strcpy(ss,"%");
    sprintf(&ss[1],"%02X$RC%1d", link->rtu , valor);

    lrc = ss[0];
    /* calculo de lrc */
    for (i=1; (i<MAX_CHAR) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);
    return true;
}


short Newtocol::armar_respuesta_read_word( struct Mewtocol_setup *link ) {
    char ss[MAX_CHAR];
    char ss1[30];
    char i,f1,f2,*pd; /* V8b */
    short principio,fin,numero;    /* byte count */
    char tipo;
    short size;
    char *memoria;
	unsigned short lrc;
	struct mem_info *mem;
	
	tipo = ver_area( link , &mem );
	
    strcpy(ss,"%");
	switch( tipo ) {
		case 'D':
		case 'L':
		case 'F':
	        principio	= get_dec(&link->parcer.irx,5); /* primeros 5 digitos y avanzo pointer */
	        fin			= get_dec(&link->parcer.irx,5);
	    	// Para las preguntas : 
	    	//   %xx#RD......
	    	sprintf(&ss[1],"%02X$RD", link->rtu ,tipo);
			break;
		case 'S':
		case 'K':
		case 'X':
		case 'Y':
		case 'R':
	        principio	= get_dec(&link->parcer.irx,4); /* primeros 4 digitos y avanzo pointer */
	        fin			= get_dec(&link->parcer.irx,4);;
	    	// Para las preguntas : 
	    	//   %xx#RCC......
	    	sprintf(&ss[1],"%02X$RC", link->rtu ,tipo);
			break;
		default:
			return false;
			break;
	}

    numero = ( fin - principio ) + 1;

	memoria = (char*) mem->origen;
	
	for(i=0; i<numero; i++) {
        pd=&memoria[principio*2+i*2];
        f1=*pd++; f2=*pd++; 
        sprintf(ss1,"%02X", f1);  strcat(ss,ss1);
        sprintf(ss1,"%02X", f2);  strcat(ss,ss1);
    }
    lrc = ss[0];
/* calculo de lrc */
    for (i=1; (i<MAX_CHAR) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);

    return true;
}

/*---------------------------------------------------------------------------*/
short Newtocol::srw_many_bit( struct Mewtocol_setup *link  ) {
    char ss[64];
    char i; /* V8b int i; */
    short mb,bo,msk;
    short numero,valor, direcc_word, direcc_bit;
    char tipo;
    short res;
	unsigned short lrc;
	struct mem_info *mem;
	
    numero = valor = get_hex(&link->parcer.irx,1); /* tomo numero y demas avanzo p  */

    if( numero < 1 || numero > 8 ) {
        return false;
    }
    for(i = 0 ; i < numero; i++ ) {
	    tipo = ver_area( link , &mem );
        if( !(tipo=='Y' ||  tipo=='R')) {
            return false;
        }
        direcc_word = get_dec(&link->parcer.irx,3); /* primeros 3 digitos */
        direcc_bit 	= get_hex(&link->parcer.irx,1); /* ultimo digitos y avanzo pointer */
        valor 		= get_hex(&link->parcer.irx,1); /* digito de valor 0,1 y demas avanzo p  */
        /* aqui diferenciar en que area escribir Y o R */
        res = wbit(mem,direcc_word,direcc_bit,valor);
        if( res == false ) {
            return false;
        }
	}
    strcpy(ss,"%");
    sprintf(&ss[1],"%02X$WC",link->rtu);
    lrc=0;
    /* calculo de lrc */
    for (i=0; (i<64) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
    }
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);
    return true;
}

short Newtocol::srw_one_bit( struct Mewtocol_setup *link ) {
    char ss[64];
    char i;     /* V8b int i; */
    short direcc_word,direcc_bit,valor;
    char tipo;
    char *b;
    short res;
	unsigned short lrc,numero;
	struct mem_info *mem;

    tipo = ver_area( link , &mem );

    if( !(tipo=='Y' || tipo=='R')) {
        return false;
    }

    direcc_word = get_dec(&link->parcer.irx,3); /* Primeros 3 digitos */
    direcc_bit 	= get_hex(&link->parcer.irx,1); /* ultimo digitos y avanzo pointer */
    valor 		= get_hex(&link->parcer.irx,1); /* digito de valor 0,1 */
    /* aqui diferenciar en que area escribir Y o R */
    /*setLCD(LINE2+9);fprintf(LCD,"%2d%2d%2d%c", direcc_word,direcc_bit,valor,*(p-1));*/
    res = wbit(mem,direcc_word,direcc_bit,valor);
    if( res == false) {
        return false;
    }
    strcpy(ss,"%");
    sprintf(&ss[1],"%02X$WC",link->rtu);
    lrc=0;
    /* calculo de lrc */
    for (i=0; (i<64) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);
    return true;
}

short Newtocol::set_y_respuesta_write_word( struct Mewtocol_setup *link ) {
    char ss[MAX_CHAR];
    char ss1[30];
    short i,principio,fin, f1,f2,numero;
    char rc; /* ret code */
    char *memoria,tipo,*pd;
	unsigned short lrc;
	struct mem_info *mem;

    tipo = ver_area( link , &mem );

    switch(tipo) {
        case 'R':
        case 'Y':
        case 'S':
        case 'K':
            principio = get_dec(&link->parcer.irx,4); /* primeros 5 digitos y avanzo pointer */
            fin		  = get_dec(&link->parcer.irx,4);
            rc='C'; /* codigo respuesta write */
            break;
        case 'D':
        case 'L':
            principio=get_dec(&link->parcer.irx,5); /* primeros 5 digitos y avanzo pointer */
            fin=get_dec(&link->parcer.irx,5);
            rc='D'; /* codigo respuesta write */
            break;
        default:
            return false;
	}

    numero = ( fin - principio ) + 1 ;

	memoria = (char*)mem->origen;
    /* aqui diferenciar de que area escribir y ver limites*/

	if( principio < mem->minimo ) {
		return false;
	}
    if( fin > mem->maximo ) {
        return false; /* si fuera de limites no responder ?? */
    }
    /* ahora datos */
    for(i=0; i<numero; i++) {
        pd=&memoria[principio*2+i*2];
        f1=get_hex(&link->parcer.irx,2); /* 2 digitos por datos */
        f2=get_hex(&link->parcer.irx,2); /* 2 digitos por datos */
        /* 4 digitos por dato avance p pointer 4 veces */
        *pd++=f1; *pd++=f2;
	}
    strcpy(ss,"%");
    sprintf(&ss[1],"%02X$W%c",link->rtu , rc);
    lrc=0;
/* calculo de lrc */
    for (i=0; (i<64) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);

    return true;
}

/*-----------------------------------------------------------------------*/


	
short Newtocol::armar_respuesta_error( struct Mewtocol_setup *link , short iderror ) {
    char ss[30];
    int i;
	unsigned int lrc;
	
    strcpy(ss,"%");
    sprintf(&ss[1],"%02X!%02X", link->rtu , iderror);
    lrc=0;
    /* calculo de lrc */
    for (i=0; (i<30) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);
    return true;
}


short Newtocol::armar_respuesta_plc( struct Mewtocol_setup *link ) {
    char ss[64];
    int i;
	unsigned int lrc;

    strcpy(ss,"%");
    sprintf(&ss[1],"%02X$RC%02d%02d%02d%02X%02X%04x",link->rtu , link->plc.id , link->plc.version,link->plc.prog_size,link->plc.op_mode,link->plc.error_flag,link->plc.error_code);
    lrc=0;
    /* calculo de lrc */
    for (i=0; (i<64) && (ss[i]!='\0') ; i++) {
        lrc=lrc^ss[i];
	}
    strcpy(link->parcer.tx_buffer,ss);
    sprintf(ss,"%02X\r", lrc);
    strcat(link->parcer.tx_buffer,ss);
    return true;
}
/*-----------------------------------------------------------------------*/



	
short Newtocol::get_dec( char **dir , short maxd ) {
    short i;
    short h, nc;
	char *s;
    s=*dir;
    h=nc=i=0;

    while ( (s[i]==' ' || s[i]==','|| s[i]=='.'|| s[i]==':'|| s[i]=='/') && s[i]!='\0') i++;
    /* paso delimitadores */
    while ( (nc!=maxd) && s[i]!=CR && s[i]!=' ' && s[i]!='.' && s[i]!=',' &&
	 s[i]!=':' && s[i]!='/' && s[i]!='\0')
    {
     if ( (s[i]>='0') && (s[i]<='9') ) 	{ h=(h * 10)+((s[i])-'0'); nc++;}
            else  { return 0;  /* aqui error de formato */
                    /* setLCD(LINE1);fprintf(LCD,"error dec");*/
                }
        i++;
    }
    if (nc!=0) { *dir=&s[i]; return h;} /* si hubo un digito actualizo */
    else  return 0;   /* si numero car=0 esto es solo CR, o '\0' ret 0 */
}

short Newtocol::get_hex( char **dir, short maxd ) {
	short i;
	short h, nc;
	char *s;
    s=*dir;
	h = nc = i = 0;
	while (( s[i]==' ' || s[i]==TAB || s[i]==',' || s[i]=='.' ) && s[i]!='\0' ) {
		i++;
	}
	/* paso delimitadores */

	while (( nc!=maxd ) && s[i]!=CR && s[i] !=' ' && s[i] !=TAB && s[i]!='.' && s[i]!=','&& s[i]!='\0' ) {
        if ( (s[i]>='0') && (s[i]<='9') ) {
            h=(h << 4)+((s[i])-'0'); nc++;
        } else if (s[i]>='a' && s[i]<='f') {
            h=(h << 4)+(s[i]-'a'+10); nc++;
        } else if (s[i]>='A' && s[i]<='F') {
            h=(h << 4)+(s[i]-'A'+10); nc++;
        } else  {
            /*setLCD(LINE1);fprintf(LCD,"error hex");*/
            return 0;  /* aqui error de formato */
        }
        i++;
    }
	if ( nc != 0 ) {
		*dir=&s[i];
		return( h ); /* si hubo un digito actualizo */
	} else {
		return( 0 );   /* si numero car=0 esto es solo CR, o '\0' ret 0 */
	}
}

void Newtocol::armar_tx( struct Mewtocol_setup *link , char *data ) {
	unsigned short aux;
	while( *data ) {
		aux = *data++;
		link->Comm->write( aux );
	}
}

void Newtocol::strcpy( char *destino , char *origen ) {
	while( *origen ) {
		*destino++ = *origen++;
	}
	*destino = *origen;
}	

void Newtocol::strcat( char *destino , char *origen ) {
	while( *destino ) {
		destino++ ;
	}
	while( *origen ) {
		*destino++ = *origen++;
	}
	*destino = *origen;
}

short Newtocol::wbit( struct mem_info *mem , short addr_word, short addr_bit, short valor ){
    short bit,mb,msk;

    if( addr_word < mem->minimo ) {
   	    return false;    /* si fuera de limites no tocar mem ?? */
	}
    if( addr_word > mem->maximo ) {
   	    return false;    /* si fuera de limites no tocar mem ?? */
    }
	
    msk = 1;
    bit= addr_bit;
    mb = addr_word;
    msk = msk << bit;
    if( valor ) {
        mem->origen[mb] = mem->origen[mb] | msk;
    } else {
        mem->origen[mb] = mem->origen[mb] & ~msk;
    }
    return true;
}
/*-------------------------------------------------------------------------*/

short Newtocol::rbit(struct mem_info *mem, short addr_word, short addr_bit ) {
    short bit,mb,msk;

    if( addr_word < mem->minimo ) {
   	    return false;    /* si fuera de limites no tocar mem ?? */
	}
    if( addr_word > mem->maximo ) {
   	    return false;    /* si fuera de limites no tocar mem ?? */
    }

    msk=1;
    bit = addr_bit;
    mb = addr_word;
    msk = msk << bit;
    if( mem->origen[mb] & msk ){
        return (true);
    } else {
        return (false);
    }
}
