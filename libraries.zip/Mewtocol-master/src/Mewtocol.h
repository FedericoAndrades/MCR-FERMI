// Cabezera Slave Mewtoocol NAIS
#include <arduino.h>

/* definiciones de polling records */
#define MAX_CHAR                	118

#define MEWTOCOL_BCC_ERROR 				0x40
#define MEWTOCOL_FORMAT_ERROR			0x41
#define MEWTOCOL_NOT_SUPPORT_ERROR		0x42
#define MEWTOCOL_PROCEDURE_ERROR		0x43

#define MEWTOCOL_COMMAND	'#'
#define MEWTOCOL_REPLY		'$'

/*---------------- definiciones de errores de comm. con plc -------- */
#define MEWTOCOL_BAD_STATION             -2
#define MEWTOCOL_MENSAJE_RECHAZADO       -15
#define MEWTOCOL_DESCONOCIDO             -18

#define MEWTOCOL_ESPERA_DATOS                	1
#define MEWTOCOL_RX_DATOS                    	2
#define MEWTOCOL_ANALIZA_DATOS               	3
#define MEWTOCOL_ARMA_RESPUESTA              	4
#define MEWTOCOL_RESPUESTA_LISTA             	5
#define MEWTOCOL_ESPERA_TIEMPO_RESPUESTA     	6
#define MEWTOCOL_PRE_TX_RESPUESTA            	7
#define MEWTOCOL_TX_RESPUESTA                	8
#define MEWTOCOL_POST_TX_RESPUESTA           	9
#define MEWTOCOL_COMM_CLOSE						0xFF

struct mem_info {
	unsigned short *origen;
	unsigned short minimo , maximo;
};

struct Mewtocol_setup {
	char rtu;
	struct mem_info mdt;
	struct mem_info mld;
	struct mem_info mr;
	struct mem_info mx;
	struct mem_info my;
	struct mem_info mt;
	struct mem_info mc;
	struct mem_info ms;
	struct mem_info mk;
	struct {
		unsigned short id;
		unsigned short version;
		unsigned short prog_size;
		unsigned short op_mode;
		unsigned short error_flag;
		unsigned short error_code;
	}plc;
	Uart *Comm;
	struct {
		short estado_rtu;
		char rx_buffer[MAX_CHAR+1];
		char tx_buffer[MAX_CHAR+1];
		char *irx;
		char *itx;
		unsigned short rts_time_on;
		unsigned short rts_time_off;
		unsigned short rpt_time;
		unsigned short rx_time_out;
		unsigned short timer;
	} parcer;	
};

#define CR 	0x0D
#define TAB	0x09

class Newtocol {
	public:
		short open_slave_nais( struct Mewtocol_setup *link ) ;
		short close_slave_nais( struct Mewtocol_setup *link ) ;
		short slave_nais( struct Mewtocol_setup *link ) ;
		void poll_timer_sl_nais( struct Mewtocol_setup *link ) ;
		Newtocol();

	private:
		short cont_reeinit;
		short analizar_comando( struct Mewtocol_setup *link ) ;
		char ver_area( struct Mewtocol_setup *link , struct mem_info **mem ) ;
		short armar_respuesta_read_many_bits( struct Mewtocol_setup *link ) ;
		short armar_respuesta_read_one_bit( struct Mewtocol_setup *link ) ;
		short armar_respuesta_read_word( struct Mewtocol_setup *link ) ;
		short srw_many_bit( struct Mewtocol_setup *link  ) ;
		short srw_one_bit( struct Mewtocol_setup *link ) ;
		short set_y_respuesta_write_word( struct Mewtocol_setup *link ) ;
		short armar_respuesta_error( struct Mewtocol_setup *link , short iderror ) ;
		short armar_respuesta_plc( struct Mewtocol_setup *link ) ;
		short get_dec( char **dir , short maxd ) ;
		short get_hex( char **dir, short maxd ) ;
		void armar_tx(struct Mewtocol_setup *link , char *data ) ;
		void strcpy( char *destino , char *origen ) ;
		void strcat( char *destino , char *origen ) ;
		short wbit( struct mem_info *mem , short addr_word, short addr_bit, short valor ) ;
		short rbit(struct mem_info *mem, short addr_word, short addr_bit ) ;
};
