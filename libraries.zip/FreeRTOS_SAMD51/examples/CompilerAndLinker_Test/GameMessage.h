
// include the other header files to make this class work
#include <FreeRTOS_SAMD51.h> //samd51
#include "GameData.h"


#ifndef GAME_MESSAGE_H
#define GAME_MESSAGE_H


  

#endif
