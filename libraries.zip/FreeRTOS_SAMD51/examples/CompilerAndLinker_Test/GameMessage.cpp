#include "GameMessage.h" // include this classes header file



